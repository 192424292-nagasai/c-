# DSA01-192424292-Assignment2

**Assignment 2 (CO2) - Functions and Object-Oriented Concepts in C++**

| | |
|---|---|
| Name | J.Nagasai |
| Register Number | 192424292 |
| Compiler | g++ (Ubuntu 13.3.0) 13.3.0 |
| Compile command | `g++ -std=c++17 -Wall -Wextra file.cpp -o file` |
| Q6 timing builds | same command with `-O0` and with `-O2` |
| OS | Linux 64-bit |

## Folder structure
```
Qn/
   *.cpp            source code
   input.txt        input file (only where the program reads input)
   output/          program output (*_output.txt) and compiler messages (*_compile.txt)
   screenshots/     screenshot of compile + run
   README.md        predictions, results, explanations and complexity analysis
```

## How to compile and run
All programs at once:
```
bash run_all.sh
```
One program, for example:
```
cd Q5
g++ -std=c++17 -Wall -Wextra q5_bus_design.cpp -o q5_bus_design
./q5_bus_design < input.txt
```
Programs that read `input.txt`: q1_three_ways, q2_marks_register, q4_savings_account, q5_bus_design, q6_tests.

Files that are **supposed to fail** compiling (evidence of the error): `Q3/q3_ambiguous.cpp`, `Q3/q3_long_ambiguous.cpp`.

## Short result of each question
| Q | Programs | Result |
|---|---|---|
| Q1 Call by value / reference / pointer | q1_predict, q1_complete, q1_three_ways | Output `1 12 13 / 1 100 / 16 13 6`. Complete-the-code matches (45000, 40500). By value leaves 45000; reference 40500; pointer 36450. Big Student by value 19x slower than const ref |
| Q2 Return by reference | q2_marks_register, q2_dangling, q2_vector_growth | `highest() += 2` and `highest() = 100` changed the array; -Wreturn-local-addr warning; reference became dangling after vector grew from capacity 4 to 8, index stayed valid |
| Q3 Defaults and overloading | q3_ambiguous, q3_courier, q3_long_ambiguous, q3_parcel_struct | Ambiguous-call error explained; redesign with 3 overloads; all 7 predicted selections correct (charge(2) -> int, charge(2.0f) -> double) |
| Q4 Class with array | q4_savings_account, q4_alternatives | Mini statement shows last 10 of 12 transactions; shift 115 ms vs circular 8 ms for K = 50 |
| Q5 Static members | q5_predict, q5_complete, q5_bus_design, q5_alternatives | Output `101 103 104 4`; complete-the-code matches; 7 students, capacity 4 -> 4 seats + 3 waiting |
| Q6 Friend and inline | q6_complete, q6_tests, q6_inline_timing (-O0, -O2), q6_public_members | `205 false`; 7/7 tests passed; at -O2 friend/member/getter all ~1.9 ns, forced noinline 3.4 ns |
| Q7 Design challenge | q7_original, q7_redesigned | Shifting array O(K): 14,888 ns per transaction at K = 5000; circular buffer ~12 ns for every K, same statement checksum |

## Assumptions
- Q1: several concessions are applied one after another (not added).
- Q3: Rs 60 per kg, minimum Rs 40, express + Rs 50, insurance + Rs 25.
- Q4: minimum balance Rs 1000 for a withdrawal.
- Timing numbers change a little on every run; the numbers in the READMEs are from the run saved in each `output/` folder.
