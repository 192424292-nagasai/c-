// Q2 - Changed condition: marks kept in a std::vector that grows
// Shows that a reference / pointer taken before push_back can become invalid,
// while an index stays valid. (We only print addresses, we never read the old reference.)
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
#include <vector>
using namespace std;

int& highestRef(vector<int>& v)
{
    size_t best = 0;
    for (size_t i = 1; i < v.size(); i++)
        if (v[i] > v[best]) best = i;
    return v[best];
}

size_t highestIndex(const vector<int>& v)
{
    size_t best = 0;
    for (size_t i = 1; i < v.size(); i++)
        if (v[i] > v[best]) best = i;
    return best;
}

int main()
{
    vector<int> marks = {67, 82, 91, 45};
    int& top = highestRef(marks);
    const int* addrBefore = &top;
    size_t topIndex = highestIndex(marks);
    size_t capBefore = marks.capacity();

    cout << "size " << marks.size() << ", capacity " << capBefore
         << ", top mark " << top << " at address " << addrBefore << '\n';

    marks.push_back(70);       // capacity is full -> vector moves to a new memory block
    cout << "after push_back: size " << marks.size() << ", capacity " << marks.capacity() << '\n';
    cout << "element " << topIndex << " is now at address " << &marks[topIndex] << '\n';
    cout << "old reference still points to " << addrBefore
         << (addrBefore != &marks[topIndex] ? "  -> DANGLING (memory was freed)\n" : "  -> still valid\n");
    cout << "index " << topIndex << " still gives " << marks[topIndex] << "  -> index is safe\n";

    cout << "\nCount how often the block moves while pushing 1000 marks:\n";
    vector<int> v;
    int moves = 0;
    const int* last = nullptr;
    for (int i = 0; i < 1000; i++) {
        v.push_back(i % 100);
        if (v.data() != last) { moves++; last = v.data(); }
    }
    cout << "memory block changed " << moves << " times (capacity now " << v.capacity() << ")\n";

    // time to find the highest mark, O(n)
    int sizes[] = {1000, 100000, 1000000};
    for (int n : sizes) {
        vector<int> big(n);
        for (int i = 0; i < n; i++) big[i] = (i * 37) % 101;
        auto t1 = chrono::steady_clock::now();
        size_t b = highestIndex(big);
        auto t2 = chrono::steady_clock::now();
        cout << "n = " << n << ": highest " << big[b] << " found in "
             << chrono::duration<double, micro>(t2 - t1).count() << " us\n";
    }
    return 0;
}
