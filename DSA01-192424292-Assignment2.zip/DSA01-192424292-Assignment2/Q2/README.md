# Q2 - Return by Reference and Its Dangers (Examination Marks Register)

## Files
| File | What it does |
|---|---|
| q2_marks_register.cpp | highest mark returned by reference, const reference, copy, index and pointer |
| input.txt | 8 marks |
| q2_dangling.cpp | returns a reference to a local variable - compiler warning |
| q2_vector_growth.cpp | changed condition: std::vector that grows, reference becomes invalid |

Run: `./q2_marks_register < input.txt`, `./q2_dangling`, `./q2_vector_growth`

## Return by reference
```cpp
int& highestRef(int marks[], int n) { ... return marks[best]; }
highestRef(marks, n) += 2;     // moderation applied directly to the array element
highestRef(marks, n) = 100;    // the call is on the LEFT of =
```
Output: `67 82 91 ...` -> `67 82 93 ...` -> `67 82 100 ...`. The reference is the array element itself, so the array changes.

## Reference vs const reference vs copy
| Return type | Can caller change the array? | Copy made? | Result in output |
|---|---|---|---|
| `int&` | yes | no | 91 -> 93 -> 100 |
| `const int&` | no (`r += 2` does not compile) | no | read 100 |
| `int` (copy) | no, only its own copy | yes (4 bytes) | copy 105, array still 100 |

## Reference to a local variable
```cpp
int& badModeration(int mark) { int moderated = mark + 2; return moderated; }
```
g++ -Wall -Wextra:
```
warning: reference to local variable 'moderated' returned [-Wreturn-local-addr]
```
`moderated` lives on the stack only while the function runs. After return its memory is released and reused by the next call, so the reference points to nothing valid (a dangling reference). Reading it is **undefined behaviour** - it may print 90, garbage, or crash (g++ at -O2 even replaces it with a null address). So the program only calls it if you run `./q2_dangling unsafe`. The fix is to return a copy (`goodModeration` gives 90).

## Changed condition - std::vector that grows
Output of q2_vector_growth:
```
size 4, capacity 4, top mark 91 at address 0x...2b8
after push_back: size 5, capacity 8
element 2 is now at address 0x...2e8
old reference still points to 0x...2b8  -> DANGLING (memory was freed)
index 2 still gives 91  -> index is safe
```
When `push_back` needs more than the capacity, the vector allocates a bigger block, copies the elements there and frees the old block. Any reference or pointer taken before that still points into the freed block. Pushing 1000 marks moved the block 11 times. An index stays correct because it is looked up again in the new block each time.

## Alternative concept and complexity
```cpp
int idx = highestIndex(marks, n);  marks[idx] += 2;     // index
int* p = highestPtr(marks, n);     if (p) *p += 2;      // pointer
highestRef(marks, n) += 2;                              // reference
```
| | index (int) | pointer (int*) | reference (int&) |
|---|---|---|---|
| Time to find highest | O(n) | O(n) | O(n) |
| Extra space | O(1) | O(1) | O(1) |
| Caller code | needs the array + index | must check nullptr, use `*` | shortest |
| After vector grows | **still valid** | dangling | dangling |
| Can be "empty" | yes (-1) | yes (nullptr) | no |

Measured O(n) search: n = 1,000 -> 10.7 us, 100,000 -> 1131 us, 1,000,000 -> 10876 us (about 10x time for 10x data).

Decision: for a fixed array, returning a reference is fine and short. For a growing vector I would return an **index**.
