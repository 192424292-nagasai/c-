// Q2 - Return by reference: Examination Marks Register
// Input (input.txt): n, then n marks
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

const int MAX = 100;

// returns a REFERENCE to the highest element - caller can change the array through it
int& highestRef(int marks[], int n)
{
    int best = 0;
    for (int i = 1; i < n; i++)
        if (marks[i] > marks[best]) best = i;
    return marks[best];
}

// const reference - caller can read it without copying, but cannot change it
const int& highestConstRef(const int marks[], int n)
{
    int best = 0;
    for (int i = 1; i < n; i++)
        if (marks[i] > marks[best]) best = i;
    return marks[best];
}

// copy - caller gets its own value, array is safe
int highestCopy(const int marks[], int n)
{
    int best = marks[0];
    for (int i = 1; i < n; i++)
        if (marks[i] > best) best = marks[i];
    return best;
}

// alternative 1: index
int highestIndex(const int marks[], int n)
{
    int best = 0;
    for (int i = 1; i < n; i++)
        if (marks[i] > marks[best]) best = i;
    return best;
}

// alternative 2: pointer
int* highestPtr(int marks[], int n)
{
    int* best = &marks[0];
    for (int i = 1; i < n; i++)
        if (marks[i] > *best) best = &marks[i];
    return best;
}

void print(const char* title, const int marks[], int n)
{
    cout << title;
    for (int i = 0; i < n; i++) cout << marks[i] << ' ';
    cout << '\n';
}

int main()
{
    int marks[MAX], n;
    cin >> n;
    for (int i = 0; i < n; i++) cin >> marks[i];
    print("Marks read           : ", marks, n);

    highestRef(marks, n) += 2;              // moderation +2 applied directly
    print("After highestRef += 2 : ", marks, n);

    highestRef(marks, n) = 100;             // function call on the LEFT of =
    print("After highestRef = 100: ", marks, n);

    const int& r = highestConstRef(marks, n);
    // r += 2;                              // compile error: r is read-only
    cout << "const ref reads " << r << " (cannot modify)\n";

    int copy = highestCopy(marks, n);
    copy += 5;                               // changes only the copy
    cout << "copy changed to " << copy << ", array still has " << highestCopy(marks, n) << '\n';

    int idx = highestIndex(marks, n);
    marks[idx] -= 1;
    print("Index version, -1     : ", marks, n);

    int* p = highestPtr(marks, n);
    if (p != nullptr) *p -= 1;
    print("Pointer version, -1   : ", marks, n);
    return 0;
}
