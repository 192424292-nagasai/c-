// Q2 - Returning a reference to a LOCAL variable (dangling reference)
// Compile with -Wall -Wextra to see the warning.
// The bad call is only made when the program gets the argument "unsafe",
// because using the result is undefined behaviour (it can crash or print garbage).
// Name: J.Nagasai   Reg No: 192424292

#include <cstring>
#include <iostream>

int& badModeration(int mark)
{
    int moderated = mark + 2;    // local variable, lives on the stack of this call only
    return moderated;            // WARNING: reference to local variable returned
}

int goodModeration(int mark)     // return a copy instead
{
    return mark + 2;
}

int main(int argc, char* argv[])
{
    std::cout << "goodModeration(88) = " << goodModeration(88) << '\n';
    if (argc > 1 && std::strcmp(argv[1], "unsafe") == 0) {
        int& r = badModeration(88);           // r refers to memory that no longer exists
        std::cout << "badModeration(88) = " << r << "  (undefined behaviour)\n";
    } else {
        std::cout << "badModeration not called (run with argument 'unsafe' to try it)\n";
    }
    return 0;
}
