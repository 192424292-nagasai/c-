#!/bin/bash
# Compiles and runs every program of Assignment 2.
# Output  -> <Qn>/output/<program>_output.txt
# Compiler messages -> <Qn>/output/<program>_compile.txt
# Usage: bash run_all.sh
FLAGS="-std=c++17 -Wall -Wextra"

run() {   # run <folder> <file.cpp> [input file] [program args] [extra flags] [exe name]
    dir=$1; src=$2; in=$3; args=$4; extra=$5; name=${6:-${src%.cpp}}
    cd "$dir" || exit 1
    mkdir -p output
    echo "== $dir/$src $extra"
    g++ $FLAGS $extra "$src" -o "$name" > "output/${name}_compile.txt" 2>&1
    if [ $? -ne 0 ]; then
        echo "   compile FAILED (see output/${name}_compile.txt)"
        cd ..; return
    fi
    if [ -n "$in" ]; then
        ./"$name" $args < "$in" > "output/${name}_output.txt" 2>&1
    else
        ./"$name" $args > "output/${name}_output.txt" 2>&1
    fi
    echo "   exit code $?"
    cd ..
}

run Q1 q1_predict.cpp
run Q1 q1_complete.cpp
run Q1 q1_three_ways.cpp input.txt
run Q2 q2_marks_register.cpp input.txt
run Q2 q2_dangling.cpp
run Q2 q2_vector_growth.cpp
run Q3 q3_ambiguous.cpp                 # expected to FAIL (ambiguous call)
run Q3 q3_long_ambiguous.cpp            # expected to FAIL (ambiguous call)
run Q3 q3_courier.cpp
run Q3 q3_parcel_struct.cpp
run Q4 q4_savings_account.cpp input.txt
run Q4 q4_alternatives.cpp
run Q5 q5_predict.cpp
run Q5 q5_complete.cpp
run Q5 q5_bus_design.cpp input.txt
run Q5 q5_alternatives.cpp
run Q6 q6_complete.cpp
run Q6 q6_tests.cpp input.txt
run Q6 q6_public_members.cpp
run Q6 q6_inline_timing.cpp "" "" "-O0" q6_inline_timing_O0
run Q6 q6_inline_timing.cpp "" "" "-O2" q6_inline_timing_O2
run Q7 q7_original.cpp
run Q7 q7_redesigned.cpp
