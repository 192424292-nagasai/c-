# Q7 - Day-4 Design Challenge: Diagnose, Redesign and Validate

Program selected: **Q4 Savings Account mini-statement** (keeps the last K transactions by shifting a fixed array).

## Files
| File | What it does |
|---|---|
| q7_original.cpp | original design: fixed array, shift left when full |
| q7_redesigned.cpp | redesign: same class interface, circular buffer with a start index |

Both programs run the **same tests and the same measurements**: the last 10 of 25 transactions (correctness), then 200,000 deposits for K = 10, 50, 500, 5000, printing ns per transaction, oldest/newest kept and a checksum of the statement.

Run: `./q7_original` and `./q7_redesigned`

## A. Diagnose the limitation
Evidence from Q4 (q4_alternatives, 1,000,000 transactions): shift **20.5 ms at K = 10 -> 115.1 ms at K = 50**. 5 times the history size gave about 5.6 times the time.

Cause: in `record()`, every new transaction when the array is full runs
```cpp
for (int i = 1; i < K; i++) txn[i - 1] = txn[i];
```
which copies K - 1 Transaction records (32 bytes each). So the cost per transaction is O(K). The design ties the **physical position** of a transaction in the array to its **age**, so every new transaction must move all the others. With 10 records nobody notices; when the bank asks for 50, 500 or more, every deposit becomes slower.

## B. Design objective (measurable)
Make the time to add one transaction **independent of K** (O(1)): for K = 5000 it should be within 2x of the K = 10 time, while the statement (order and content) stays exactly the same (same checksum) and memory grows by at most a few bytes.

## C. Revised solution
Change: keep the array, stop moving data. Add one `int start` = index of the oldest transaction.

```
class SavingsAccount<K>
 - balance : long long
 - txn[K]  : Transaction
 - start   : int          <-- NEW (4 bytes)
 - count   : int
 - totalTxn: int
 + deposit(amount)
 + get(i) : Transaction   (i = 0 is oldest)  -> txn[(start + i) % K]
 + size()  : int

deposit(amount):
    balance <- balance + amount
    t <- new transaction
    IF count < K THEN
        txn[(start + count) % K] <- t ;  count <- count + 1
    ELSE
        txn[start] <- t                      // overwrite the oldest
        start <- (start + 1) % K
    END IF
```
- C++ features used: class template parameter K (array size known at compile time), modulo `%` index arithmetic, same public interface (`get(i)`, `size()`), so the mini-statement code does not change.
- No library container used; no heap allocation.
- Extra memory: one int (4 bytes) - sizeof went from 1616 to 1624 bytes for K = 50 (8 with padding).
- New trade-off: every read `get(i)` now does a `%` (slightly more work when printing), and the code is a little harder to read.

## D. Prediction (before implementing)
- Original: ns per transaction grows roughly linearly with K (K = 5000 about 500x K = 10).
- Redesign: roughly constant, about 10-15 ns per transaction for every K.
- Checksums of both versions identical for every K.

## E. Implement and validate - Original vs Redesigned
Correctness (last 10 of 25 transactions): both print `16 17 18 19 20 21 22 23 24 25`, checksum `373554091640400905` in both.

| K | Original (ns / txn) | Redesigned (ns / txn) | Speed-up | Checksum same? |
|---|---|---|---|---|
| 10 | 27.7 | 33.9 | 0.8x (slower) | yes |
| 50 | 150.7 | 11.3 | 13x | yes |
| 500 | 1621.1 | 12.0 | 135x | yes |
| 5000 | 14888.0 | 11.7 | 1272x | yes |

(200,000 deposits each, g++ -std=c++17 -Wall -Wextra, no optimisation flag. Oldest/newest kept transaction numbers are the same in both versions for every K.)

## F. Defend the final design
- **Objective achieved:** the redesigned time stayed about 11-12 ns from K = 50 to K = 5000 (O(1)), while the original grew from 151 ns to 14,888 ns (O(K)). The statements are identical (same checksums), memory grew by only 8 bytes.
- **Prediction:** correct for K >= 50. At K = 10 the redesign was not faster in this run (33.9 vs 27.7 ns). Reasons: K = 10 is the first test in the program (cold cache / timer warm-up), and with only 9 copies the shifting loop is very cheap while the redesign pays for `%` divisions. In an earlier run the K = 10 numbers were 27.5 vs 10.5 ns, so at this size the difference is within measurement noise.
- **New costs:** each `get(i)` does a modulo; the code is slightly harder to read and to debug (the oldest record is not at index 0).
- **Where the original is still preferable:** for small fixed K (like the bank's original 10), when simplicity matters more than speed, or if other code needs `txn[0]` to always be the oldest (e.g. writing the raw array directly to a file).
- **Conclusion:** for the bank's new requirement (50 transactions and possibly more), the circular buffer is the better design: same interface, same output, constant time per transaction.
