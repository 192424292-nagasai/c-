// Q7 - REDESIGNED: SavingsAccount keeps the last K transactions in a CIRCULAR buffer.
// A start index marks the oldest transaction; when full, the new transaction
// overwrites the oldest one and start moves forward. No shifting.
// Same tests and measurements as q7_original.cpp.
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
using namespace std;

struct Transaction {
    char type;
    long long amount;
    long long balanceAfter;
    int number;
};

template <int K>
class SavingsAccount {
    long long balance;
    Transaction txn[K];
    int start;          // NEW: index of the oldest transaction (4 extra bytes)
    int count;
    int totalTxn;
public:
    SavingsAccount(long long opening) : balance(opening), start(0), count(0), totalTxn(0) {}

    void deposit(long long amount)
    {
        balance += amount;
        totalTxn++;
        Transaction t = {'D', amount, balance, totalTxn};
        if (count < K) {
            txn[(start + count) % K] = t;
            count++;
        } else {
            txn[start] = t;                 // overwrite the oldest - 1 copy only
            start = (start + 1) % K;
        }
    }

    // same interface as before: i = 0 is the oldest kept
    const Transaction& get(int i) const { return txn[(start + i) % K]; }
    int size() const { return count; }

    unsigned long long checksum() const
    {
        unsigned long long s = 0;
        for (int i = 0; i < count; i++) s = s * 31 + get(i).number + get(i).balanceAfter;
        return s;
    }
};

template <int K>
void runTest(int n)
{
    static SavingsAccount<K> acc(0);
    acc = SavingsAccount<K>(0);
    auto t1 = chrono::steady_clock::now();
    for (int i = 1; i <= n; i++) acc.deposit(i % 1000 + 1);
    auto t2 = chrono::steady_clock::now();
    double ns = chrono::duration<double, nano>(t2 - t1).count() / n;
    cout << "K = " << K << "\t" << ns << " ns per transaction\toldest kept #" << acc.get(0).number
         << "\tnewest #" << acc.get(acc.size() - 1).number << "\tchecksum " << acc.checksum() << '\n';
}

int main()
{
    cout << "REDESIGNED (circular buffer)\n";
    SavingsAccount<10> small(0);
    for (int i = 1; i <= 25; i++) small.deposit(i * 100);
    cout << "Correctness - last 10 of 25 transactions: ";
    for (int i = 0; i < small.size(); i++) cout << small.get(i).number << ' ';
    cout << "\nchecksum " << small.checksum() << "\n\n";

    const int N = 200000;
    cout << "Adding " << N << " transactions:\n";
    runTest<10>(N);
    runTest<50>(N);
    runTest<500>(N);
    runTest<5000>(N);
    cout << "sizeof(SavingsAccount<50>) = " << sizeof(SavingsAccount<50>) << " bytes\n";
    return 0;
}
