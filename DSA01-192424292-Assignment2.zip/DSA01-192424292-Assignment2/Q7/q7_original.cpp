// Q7 - ORIGINAL design (from Q4): SavingsAccount keeps the last K transactions
// in a fixed array and SHIFTS the whole array when it is full.
// Same tests and measurements as q7_redesigned.cpp.
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
using namespace std;

struct Transaction {
    char type;
    long long amount;
    long long balanceAfter;
    int number;
};

template <int K>
class SavingsAccount {
    long long balance;
    Transaction txn[K];
    int count;
    int totalTxn;
public:
    SavingsAccount(long long opening) : balance(opening), count(0), totalTxn(0) {}

    void deposit(long long amount)
    {
        balance += amount;
        totalTxn++;
        if (count == K) {                          // full: shift left by one -> K-1 copies
            for (int i = 1; i < K; i++) txn[i - 1] = txn[i];
            count--;
        }
        txn[count++] = {'D', amount, balance, totalTxn};
    }

    // i = 0 is the oldest transaction kept
    const Transaction& get(int i) const { return txn[i]; }
    int size() const { return count; }

    unsigned long long checksum() const      // to prove both designs give the same statement
    {
        unsigned long long s = 0;
        for (int i = 0; i < count; i++) s = s * 31 + get(i).number + get(i).balanceAfter;
        return s;
    }
};

template <int K>
void runTest(int n)
{
    static SavingsAccount<K> acc(0);
    acc = SavingsAccount<K>(0);
    auto t1 = chrono::steady_clock::now();
    for (int i = 1; i <= n; i++) acc.deposit(i % 1000 + 1);
    auto t2 = chrono::steady_clock::now();
    double ns = chrono::duration<double, nano>(t2 - t1).count() / n;
    cout << "K = " << K << "\t" << ns << " ns per transaction\toldest kept #" << acc.get(0).number
         << "\tnewest #" << acc.get(acc.size() - 1).number << "\tchecksum " << acc.checksum() << '\n';
}

int main()
{
    cout << "ORIGINAL (shifting array)\n";
    SavingsAccount<10> small(0);
    for (int i = 1; i <= 25; i++) small.deposit(i * 100);
    cout << "Correctness - last 10 of 25 transactions: ";
    for (int i = 0; i < small.size(); i++) cout << small.get(i).number << ' ';
    cout << "\nchecksum " << small.checksum() << "\n\n";

    const int N = 200000;
    cout << "Adding " << N << " transactions:\n";
    runTest<10>(N);
    runTest<50>(N);
    runTest<500>(N);
    runTest<5000>(N);
    cout << "sizeof(SavingsAccount<50>) = " << sizeof(SavingsAccount<50>) << " bytes\n";
    return 0;
}
