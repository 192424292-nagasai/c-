// Q3 - Courier Charge Calculator, redesigned
//  * default arguments for express / insured (short common calls)
//  * overloading on the KIND of input: grams (int), kg (double), Parcel object
//  * only ONE function per kind of input -> no ambiguous call
// Charges (all in paise): Rs 60 per kg (6 paise per gram), minimum Rs 40,
// express + Rs 50, insurance + Rs 25
// Name: J.Nagasai   Reg No: 192424292

#include <cmath>
#include <iostream>
#include <string>
using namespace std;

const long long PAISE_PER_GRAM = 6;
const long long MIN_CHARGE = 4000;
const long long EXPRESS_EXTRA = 5000;
const long long INSURANCE_EXTRA = 2500;

struct Parcel {
    int grams;
    bool express;
    bool insured;
};

string lastCalled;   // just to show which overload was selected

// (A) weight in grams
long long charge(int grams, bool express = false, bool insured = false)
{
    lastCalled = "charge(int grams, ...)";
    long long c = grams * PAISE_PER_GRAM;
    if (c < MIN_CHARGE) c = MIN_CHARGE;
    if (express) c += EXPRESS_EXTRA;
    if (insured) c += INSURANCE_EXTRA;
    return c;
}

// (B) weight in kg - converts to grams and reuses (A)
long long charge(double kg, bool express = false, bool insured = false)
{
    long long c = charge(static_cast<int>(llround(kg * 1000)), express, insured);
    lastCalled = "charge(double kg, ...)";
    return c;
}

// (C) a whole Parcel object (passed by const reference, nothing big copied)
long long charge(const Parcel& p)
{
    long long c = charge(p.grams, p.express, p.insured);
    lastCalled = "charge(const Parcel&)";
    return c;
}

string rs(long long p)
{
    return "Rs " + to_string(p / 100) + "." + (p % 100 < 10 ? "0" : "") + to_string(p % 100);
}

void show(const string& call, long long result)
{
    cout << call;
    for (size_t i = call.size(); i < 30; i++) cout << ' ';
    cout << "-> " << lastCalled;
    for (size_t i = lastCalled.size(); i < 26; i++) cout << ' ';
    cout << rs(result) << '\n';
}

int main()
{
    Parcel gift{1200, true, true};

    show("charge(2)",                charge(2));                 // int exact match (2 grams!)
    show("charge(2.0f)",             charge(2.0f));              // float -> double promotion
    show("charge(2.5)",              charge(2.5));               // double exact, 2.5 kg
    show("charge(750, true)",        charge(750, true));         // int, insured default false
    show("charge(1.5, true, true)",  charge(1.5, true, true));   // double, no defaults
    show("charge(gift)",             charge(gift));              // Parcel overload
    show("charge('A')",              charge('A'));               // char -> int promotion (65 g)
    // charge(2L);   // long: conversion to int and to double are equally good -> ambiguous
    return 0;
}
