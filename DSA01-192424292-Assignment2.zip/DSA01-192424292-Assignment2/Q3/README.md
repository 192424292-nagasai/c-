# Q3 - Default Arguments and Function Overloading (Courier Charge Calculator)

## Files
| File | What it does |
|---|---|
| q3_ambiguous.cpp | developer's original 3 functions - **expected to fail** (ambiguous calls) |
| q3_courier.cpp | redesigned: charge(int grams,...), charge(double kg,...), charge(const Parcel&) |
| q3_long_ambiguous.cpp | **expected to fail**: shows charge(2L) is still ambiguous |
| q3_parcel_struct.cpp | alternative: one Parcel struct with optional fields + a function template |

Charges used (my assumption): Rs 60 per kg (6 paise per gram), minimum Rs 40, express + Rs 50, insurance + Rs 25. Money is kept in paise.

## The compiler error explained
```
error: call of overloaded 'charge(double)' is ambiguous
note: candidate: 'double charge(double)'
note: candidate: 'double charge(double, bool, bool)'
error: call of overloaded 'charge(double, bool)' is ambiguous
```
`charge(2.0)` can be called as `charge(double)` **or** as `charge(double, false, false)` using the defaults. Both are exact matches, so the compiler cannot choose. Same for `charge(2.0, true)`. Default arguments make one function behave like 3 functions, and two of them clash with the other overloads.

## Redesign
- Only ONE function per kind of input; defaults are on that one function.
- `charge(int grams, bool express = false, bool insured = false)`
- `charge(double kg, bool express = false, bool insured = false)` - converts to grams and calls the int version
- `charge(const Parcel& p)`

## Predicted vs observed selection
| Call | Predicted (before running) | Rule | Observed | Charge |
|---|---|---|---|---|
| charge(2) | int version | exact match (int) | charge(int grams, ...) | Rs 40.00 (2 g -> minimum) |
| charge(2.0f) | double version | float -> double is a **promotion** | charge(double kg, ...) | Rs 120.00 |
| charge(2.5) | double version | exact match | charge(double kg, ...) | Rs 150.00 |
| charge(750, true) | int version, insured default | exact match | charge(int grams, ...) | Rs 95.00 |
| charge(1.5, true, true) | double version | exact match | charge(double kg, ...) | Rs 165.00 |
| charge(gift) | Parcel version | exact match (reference binding) | charge(const Parcel&) | Rs 147.00 |
| charge('A') | int version | char -> int **promotion** | charge(int grams, ...) | Rs 40.00 |

All predictions were correct. Note `charge(2)` means 2 **grams**, not 2 kg - a caller who means kg must write 2.0. This is a real usability trap of overloading on int/double.

`charge(2L)` (long) still fails: long -> int and long -> double are both standard **conversions** of the same rank, so it is ambiguous (see q3_long_ambiguous_compile.txt).

## How the compiler chooses
1. Find all functions with that name that can take this number of arguments (counting defaults).
2. Rank each argument: **exact match** (incl. array/qualification adjustments) > **promotion** (char/short -> int, float -> double, bool -> int) > **standard conversion** (int <-> double, long -> int, ...) > user-defined conversion.
3. The best function must be at least as good for every argument and better for one. If two are equally good -> ambiguous error.

## Why defaults must be from the right
Arguments are matched left to right. `f(int a = 1, int b)` would make `f(5)` unclear (is 5 for a or b?), so C++ only allows defaults on the last parameters: once a parameter has a default, all parameters after it must have one too.

## Alternative concept and complexity
| | overloads + defaults | one Parcel struct | function template |
|---|---|---|---|
| Choosing the function | compile time, no run-time cost | no choice needed | compile time (instantiation) |
| Time per call | O(1) | O(1) | O(1) |
| Space copied per call | 4-8 B + 2 bools; Parcel by const ref = 8 B address | 8 B address (Parcel is 8 B) | weight + 2 bools |
| New option (e.g. fragile) | add a parameter to every overload, or a new overload (risk of ambiguity) | add one field with a default (`bool fragile = false;`) - done in q3_parcel_struct | add parameter once |
| charge(2L) | ambiguous | n/a | works (2L treated as grams) |

The Parcel struct handles new options most easily; the overloads give the shortest calls for the common cases.
