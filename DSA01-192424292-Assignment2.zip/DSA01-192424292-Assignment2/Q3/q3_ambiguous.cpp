// Q3 - The developer's original code. EXPECTED TO FAIL compiling (ambiguous calls).
// Name: J.Nagasai   Reg No: 192424292
#include <iostream>

double charge(double weight) { return weight * 60; }
double charge(double weight, bool express) { return weight * 60 + (express ? 50 : 0); }
double charge(double weight, bool express = false, bool insured = false)
{
    return weight * 60 + (express ? 50 : 0) + (insured ? 25 : 0);
}

int main()
{
    std::cout << charge(2.0) << '\n';        // matches charge(double) AND charge(double, false, false)
    std::cout << charge(2.0, true) << '\n';  // matches charge(double,bool) AND charge(double, true, false)
    std::cout << charge(2.0, true, true) << '\n';  // only the 3-parameter one - this line alone is fine
}
