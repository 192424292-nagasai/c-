// Q3 - EXPECTED TO FAIL: even the redesigned set is ambiguous for a long argument,
// because long -> int and long -> double are both "conversions" (same rank).
// Name: J.Nagasai   Reg No: 192424292
#include <iostream>

long long charge(int grams, bool express = false, bool insured = false)
{ return grams * 6 + (express ? 5000 : 0) + (insured ? 2500 : 0); }
long long charge(double kg, bool express = false, bool insured = false)
{ return charge(static_cast<int>(kg * 1000), express, insured); }

int main()
{
    std::cout << charge(2L) << '\n';
}
