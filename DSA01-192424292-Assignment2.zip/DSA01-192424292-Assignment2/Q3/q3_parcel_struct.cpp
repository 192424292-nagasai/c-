// Q3 - Alternative: one function taking a Parcel structure with optional fields
// (default member initialisers), and a function template version.
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
#include <type_traits>
using namespace std;

struct Parcel {
    int grams = 0;
    bool express = false;     // optional fields with defaults
    bool insured = false;
    bool fragile = false;     // NEW option: one new field, no new overload
};

long long charge(const Parcel& p)
{
    long long c = p.grams * 6LL;
    if (c < 4000) c = 4000;
    if (p.express) c += 5000;
    if (p.insured) c += 2500;
    if (p.fragile) c += 1500;
    return c;
}

// template: one body for any number type; grams if integer, kg if floating
template <typename W>
long long chargeT(W weight, bool express = false, bool insured = false)
{
    Parcel p;
    if (is_floating_point<W>::value) p.grams = static_cast<int>(weight * 1000 + 0.5);
    else p.grams = static_cast<int>(weight);
    p.express = express;
    p.insured = insured;
    return charge(p);
}

int main()
{
    Parcel a;              a.grams = 750; a.express = true;
    Parcel b;              b.grams = 1500; b.express = true; b.insured = true;
    Parcel c;              c.grams = 2000; c.fragile = true;

    cout << "Parcel 750 g express          : " << charge(a) << " paise\n";
    cout << "Parcel 1500 g express+insured : " << charge(b) << " paise\n";
    cout << "Parcel 2000 g fragile (new)   : " << charge(c) << " paise\n";
    cout << "chargeT(2)    int -> grams    : " << chargeT(2) << " paise\n";
    cout << "chargeT(2.0f) float -> kg     : " << chargeT(2.0f) << " paise\n";
    cout << "chargeT(2L)   long -> grams   : " << chargeT(2L) << " paise (no ambiguity)\n";
    cout << "sizeof(Parcel) = " << sizeof(Parcel) << " bytes\n";
    return 0;
}
