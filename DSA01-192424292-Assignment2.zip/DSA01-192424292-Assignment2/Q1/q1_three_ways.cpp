// Q1 - Hostel Fee Concession Updater: by value, by reference, by pointer,
// + return-the-new-fee version, const reference, and copy cost of a big Student
// Input (input.txt): name fee concessionCode...  (M = merit 10, S = sports 15, P = single parent 25), line ends with '.'
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
#include <string>
using namespace std;

const int MERIT = 10, SPORTS = 15, SINGLE_PARENT = 25;

// 1. by value - parameter is a new local variable (copy on the stack)
void concessionByValue(long long fee, int percent)
{
    fee -= fee * percent / 100;
    cout << "   inside byValue     : " << fee << " (address of fee " << &fee << ")\n";
}

// 2. by reference - parameter is another name for the caller's variable
void concessionByRef(long long& fee, int percent)
{
    fee -= fee * percent / 100;
    cout << "   inside byReference : " << fee << " (address of fee " << &fee << ")\n";
}

// 3. by pointer - parameter is a copy of the address, *fee is the caller's variable
void concessionByPtr(long long* fee, int percent)
{
    if (fee == nullptr) return;
    *fee -= *fee * percent / 100;
    cout << "   inside byPointer   : " << *fee << " (fee points to " << fee << ")\n";
}

// 4. returns the new fee - caller decides where to store it (my chosen design)
long long withConcession(long long fee, int percent)
{
    return fee - fee * percent / 100;
}

// a big object, to show copy cost
struct Student {
    char name[50];
    long long fee;
    int marks[1000];          // about 4 KB
};

long long readFeeByValue(Student s) { return s.fee; }          // copies whole Student
long long readFeeByConstRef(const Student& s) { return s.fee; } // copies only an address

int percentFor(char code)
{
    switch (code) {
        case 'M': return MERIT;
        case 'S': return SPORTS;
        case 'P': return SINGLE_PARENT;
        default:  return 0;
    }
}

int main()
{
    cout << "---- Part 1: one call each, fee 45000, merit 10% ----\n";
    long long fee = 45000;
    cout << "caller fee address " << &fee << "\n";
    concessionByValue(fee, MERIT);
    cout << "stored fee after byValue     = " << fee << "\n";
    concessionByRef(fee, MERIT);
    cout << "stored fee after byReference = " << fee << "\n";
    concessionByPtr(&fee, MERIT);
    cout << "stored fee after byPointer   = " << fee << "\n";

    cout << "\n---- Part 2: several concessions per student (from input.txt) ----\n";
    string name;
    long long original;
    while (cin >> name >> original) {
        long long newFee = original;
        char code;
        cout << name << ": " << original;
        while (cin >> code && code != '.') {
            newFee = withConcession(newFee, percentFor(code));   // applied one after another
            cout << " -" << code << "-> " << newFee;
        }
        cout << "   (original " << original << " kept, final " << newFee << ")\n";
    }

    cout << "\n---- Part 3: bytes copied per call ----\n";
    cout << "long long by value      : " << sizeof(long long) << " bytes\n";
    cout << "long long by reference  : " << sizeof(long long*) << " bytes (an address)\n";
    cout << "Student by value        : " << sizeof(Student) << " bytes\n";
    cout << "Student by const ref    : " << sizeof(Student*) << " bytes (an address)\n";

    static Student s{};
    s.fee = 45000;
    const int N = 1000000;
    volatile long long sink = 0;
    auto t1 = chrono::steady_clock::now();
    for (int i = 0; i < N; i++) sink = sink + readFeeByValue(s);
    auto t2 = chrono::steady_clock::now();
    for (int i = 0; i < N; i++) sink = sink + readFeeByConstRef(s);
    auto t3 = chrono::steady_clock::now();
    cout << "1,000,000 calls, Student by value    : "
         << chrono::duration<double, milli>(t2 - t1).count() << " ms\n";
    cout << "1,000,000 calls, Student by const ref: "
         << chrono::duration<double, milli>(t3 - t2).count() << " ms\n";
    return 0;
}
