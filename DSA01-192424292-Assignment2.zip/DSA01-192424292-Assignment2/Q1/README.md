# Q1 - Call by Value, by Reference and by Pointer (Hostel Fee Concession Updater)

## Files
| File | What it does |
|---|---|
| q1_predict.cpp | given Predict-the-Output program (not changed) |
| q1_complete.cpp | Complete-the-Code, TODO 1 filled |
| q1_three_ways.cpp | concession by value / by reference / by pointer, return-new-fee version, bytes copied for a big Student |
| input.txt | students with one or more concessions (M = merit 10%, S = sports 15%, P = single parent 25%) |

Run: `./q1_three_ways < input.txt`

## Predict the Output
My predicted output (written before running):
```
1 12 13
1 100
16 13 6
```
Actual output:
```
1 12 13
1 100
16 13 6
```
No difference.

| Call | What changed and why |
|---|---|
| `change(a, b, &c)` | `a` is a copy, so main's a stays 1. `b` is a reference, so main's b becomes 12. `c` gets the address, `*c += 10` changes main's c to 13. |
| `bigger(a, c) = 100` | returns a reference to the bigger one: 13 > 1, so it returns c, and c becomes 100. a stays 1. |
| `show(1)` | y = 5 and z = 10 (both defaults used): 1 + 5 + 10 = 16 |
| `show(1, 2)` | only z = 10 default used: 1 + 2 + 10 = 13 |
| `show(1, 2, 3)` | no defaults used: 6 |

## Complete the Code
```cpp
void applyConcession(long long& fee, int percent)
{
    fee -= fee * percent / 100;
}
```
| Expected | Actual |
|---|---|
| after call by value : 45000 | after call by value : 45000 |
| after call by reference: 40500 | after call by reference: 40500 |

The call by value leaves the fee at 45000 because `applyByValue` gets a **copy** of hostelFee in its own parameter variable. It reduces the copy to 40500, and the copy is destroyed when the function returns. hostelFee itself was never touched.

## Three versions - predicted and observed (fee 45000, merit 10%)
| Version | Predicted stored fee | Observed | Where the parameter is stored |
|---|---|---|---|
| by value | 45000 | 45000 | a new local variable on the function's stack (different address in output) |
| by reference | 40500 | 40500 | no new variable, the reference is another name for the caller's fee (same address in output) |
| by pointer | 36450 | 36450 | a local copy of the address; `*fee` is the caller's fee (same address) |

Only reference and pointer change the caller's fee, because both reach the caller's memory. By value works on a copy.

**When to use const reference:** when the function only needs to read a large object, e.g. `long long feeOf(const Student& s)`. Nothing is copied (only an address), and the compiler stops the function from changing it.

## Design decision - several concessions
I chose **return the new fee**: `long long withConcession(long long fee, int percent)`.
- The original fee is kept (output: "original 60000 kept, final 34425"), so the office can print both.
- Concessions can be chained in any order: `fee = withConcession(withConcession(fee, 10), 15);`
- No hidden change to the caller's data; easier to test.
- Changing in place is fine only when the stored record must be updated at once, but then applying the function twice by mistake reduces the fee twice.

Note: concessions are applied one after another (60000 -> 54000 -> 45900 -> 34425), not added together (50% of 60000 = 30000). This is my assumption.

## Alternative concept and complexity
| Passing | Time | Bytes copied: long long | Bytes copied: Student (4064 B) | Measured, 1,000,000 calls with Student |
|---|---|---|---|---|
| by value | O(1) | 8 | 4064 | 56.1 ms |
| by reference | O(1) | 8 (an address) | 8 | - |
| by const reference | O(1) | 8 (an address) | 8 | 2.9 ms |
| return new fee | O(1) | 8 in + 8 out | - | - |

For a long long there is no real difference. For a big Student, by value copies the whole object every call (about 19x slower here), so const reference is used.
