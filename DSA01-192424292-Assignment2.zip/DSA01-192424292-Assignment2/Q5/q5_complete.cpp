// Q5 - Complete the Code (TODO 1 and TODO 2 filled, rest unchanged)
// Name: J.Nagasai   Reg No: 192424292
#include <iostream>
#include <string>

class BusTicket {
    static int issued; // shared by all BusTicket objects
    static const int CAPACITY = 3;
    int seat;
    std::string name;
public:
    explicit BusTicket(const std::string& n) : seat(0), name(n)
    {
        // TODO 1: If fewer than CAPACITY tickets have been issued, increase issued and
        // give this ticket the next seat number; otherwise leave seat as 0 (waiting
        // list)
        if (issued < CAPACITY) {
            issued++;
            seat = issued;
        }
    }
    static int count()
    {
        // TODO 2: Return the number of seats issued so far
        return issued;
    }
    void print() const
    {
        std::cout << name << ": "
                  << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting")) << '\n';
    }
};

int BusTicket::issued = 0; // definition of the static data member

int main()
{
    BusTicket trip[4] = {BusTicket("Asha"), BusTicket("Bala"),
                         BusTicket("Chitra"), BusTicket("Dev")};
    for (const BusTicket& t : trip) t.print();
    std::cout << "Issued: " << BusTicket::count() << '\n';
}
