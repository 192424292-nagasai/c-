// Q5 - Alternatives to the static counter:
//  (1) a global variable     (2) a TicketOffice object passed to every ticket
// Shows that only the TicketOffice design can run two buses at once.
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
#include <string>
using namespace std;

// ---------- (1) global counter ----------
int g_issued = 0;                // anyone can change it
const int G_CAPACITY = 3;

struct GlobalTicket {
    int seat = 0;
    explicit GlobalTicket(int) { if (g_issued < G_CAPACITY) seat = ++g_issued; }
};

// ---------- (2) TicketOffice ----------
class TicketOffice {
    int issued = 0;
    int capacity;
    string bus;
public:
    TicketOffice(const string& b, int cap) : capacity(cap), bus(b) {}
    int nextSeat() { return issued < capacity ? ++issued : 0; }
    int count() const { return issued; }
    string name() const { return bus; }
};

class OfficeTicket {
    int seat;
    string name;
public:
    OfficeTicket(TicketOffice& office, const string& n) : seat(office.nextSeat()), name(n) {}
    int getSeat() const { return seat; }
};

int main()
{
    cout << "(1) Global counter\n";
    GlobalTicket a(0), b(0);
    g_issued = 0;                              // some other code resets it by mistake
    GlobalTicket c(0);
    cout << "  seats: " << a.seat << ' ' << b.seat << ' ' << c.seat
         << "  <- seat 1 given twice, nothing stopped it\n";

    cout << "(2) TicketOffice per bus\n";
    TicketOffice bus1("Bus 1", 3), bus2("Bus 2", 2);
    string names[] = {"Asha", "Bala", "Chitra", "Dev"};
    for (const string& n : names) {
        OfficeTicket t1(bus1, n), t2(bus2, n);
        cout << "  " << n << ": " << bus1.name() << " seat " << t1.getSeat()
             << ", " << bus2.name() << " seat " << t2.getSeat() << '\n';
    }
    cout << "  issued: Bus 1 = " << bus1.count() << ", Bus 2 = " << bus2.count()
         << "  (two separate counters)\n";
    cout << "  sizeof(TicketOffice) = " << sizeof(TicketOffice)
         << ", each OfficeTicket also needs the office passed in\n";
    return 0;
}
