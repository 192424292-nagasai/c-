// Q5 - College Bus Seat Tickets: my class design from the principle
// "data that belongs to the whole class exists only once"
//  - static: issued (seats given), waiting (waiting list size), CAPACITY
//  - non-static: seat, waitNo, name  (belong to one ticket)
// Input (input.txt): number of students, then their names (more than capacity)
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
#include <string>
using namespace std;

class BusTicket {
    static int issued;                 // declared here...
    static int waiting;
    static const int CAPACITY = 4;
    int seat;                          // 0 = on waiting list
    int waitNo;                        // position in waiting list
    string name;
public:
    BusTicket() : seat(0), waitNo(0), name("-") {}      // needed for an array without initialisers
    explicit BusTicket(const string& n) : seat(0), waitNo(0), name(n) { book(); }

    void assign(const string& n) { name = n; book(); }

    void book()
    {
        if (issued < CAPACITY) seat = ++issued;
        else waitNo = ++waiting;
    }

    static int seatsIssued() { return issued; }       // no 'this' -> only static members
    static int waitingCount() { return waiting; }
    static int capacity() { return CAPACITY; }
    // static int mySeat() { return seat; }         // ERROR: static function has no object (no this)

    void print() const
    {
        cout << "  " << name << ": ";
        if (seat) cout << "Seat " << seat << '\n';
        else cout << "Waiting list #" << waitNo << '\n';
    }
};

int BusTicket::issued = 0;     // ...and DEFINED once, outside the class, in one .cpp file
int BusTicket::waiting = 0;

void morningTrip(const string& who)
{
    BusTicket t(who);          // local object, destroyed at the end of the function
    t.print();
}

int main()
{
    int n;
    cin >> n;
    BusTicket tickets[10];     // array of objects - default constructor runs 10 times, books nothing
    cout << "Array of 10 created, seats issued = " << BusTicket::seatsIssued() << "\n\n";

    cout << "Booking " << n << " students (capacity " << BusTicket::capacity() << "):\n";
    for (int i = 0; i < n && i < 10; i++) {
        string name;
        cin >> name;
        tickets[i].assign(name);
    }
    for (int i = 0; i < n && i < 10; i++) tickets[i].print();
    cout << "Seats issued: " << BusTicket::seatsIssued()
         << ", waiting: " << BusTicket::waitingCount() << "\n\n";

    cout << "Tickets created inside a function called twice:\n";
    morningTrip("Guest1");
    morningTrip("Guest2");
    cout << "Waiting after the 2 calls: " << BusTicket::waitingCount()
         << "  (count keeps growing - static survives the local objects)\n\n";

    cout << "sizeof(BusTicket) = " << sizeof(BusTicket)
         << " bytes (static members are NOT inside each object)\n";
    return 0;
}
