# Q5 - Static Members and Arrays of Objects (College Bus Seat Tickets)

## Files
| File | What it does |
|---|---|
| q5_predict.cpp | given Token program (not changed) |
| q5_complete.cpp | Complete-the-Code, TODO 1 and TODO 2 filled |
| q5_bus_design.cpp | my own design: array of 10 tickets, capacity 4, waiting list, function called twice |
| input.txt | 7 student names (more than the capacity) |
| q5_alternatives.cpp | global counter vs TicketOffice object, two buses at once |

Run: `./q5_bus_design < input.txt`

## From the principle to the design
"Data that belongs to the whole class should exist only once."

| Member | static? | Reason |
|---|---|---|
| issued (seats given so far) | **static** | belongs to the bus, not to one ticket |
| waiting (waiting list size) | **static** | same |
| CAPACITY | **static const** | same for all tickets |
| seatsIssued(), waitingCount() | **static functions** | the office must ask without any ticket object: `BusTicket::seatsIssued()` |
| seat, waitNo, name | normal | different for each ticket |

- A static data member is **declared** in the class and **defined once outside**, in one .cpp file: `int BusTicket::issued = 0;` (otherwise the linker gives "undefined reference").
- A static member function has **no `this` pointer**, because it is not called on an object. So it cannot use `seat` or `name` - which ticket's seat would it be? (`static int mySeat() { return seat; }` does not compile.)
- `sizeof(BusTicket)` = 40 bytes: only seat, waitNo and name. The static members are not inside any object.

## Predict the Output (Token)
My predicted output: `101 103 104 4`
Actual output: `101 103 104 4` - no difference.

`next` starts at 100 because of `int Token::next = 100;`. The constructor ran **4 times** (3 for `counter[3]`, 1 for `extra`), each time `++next`, giving ids 101, 102, 103, 104. `issued()` = 104 - 100 = 4.

## Complete the Code
```cpp
// TODO 1
if (issued < CAPACITY) {
    issued++;
    seat = issued;
}
// TODO 2
return issued;
```
| Expected | Actual |
|---|---|
| Asha: Seat 1 / Bala: Seat 2 / Chitra: Seat 3 / Dev: Waiting / Issued: 3 | same |

## Test of my design (7 students, capacity 4)
| Student | Result |
|---|---|
| Asha, Bala, Chitra, Dev | Seat 1, 2, 3, 4 |
| Elan, Farah, Gopi | Waiting list #1, #2, #3 |
| Seats issued / waiting | 4 / 3 |

**Array of objects:** `BusTicket tickets[10];` calls the default constructor 10 times (needs a default constructor). It books nothing, so seats issued is still 0. Then `assign(name)` books each one. The Complete-the-Code version uses an initialiser list instead: `BusTicket trip[4] = {BusTicket("Asha"), ...}` - the constructor with a name runs once per element.

**Tickets made inside a function called twice:** `morningTrip("Guest1")` and `morningTrip("Guest2")` each create a local ticket that is destroyed at the end of the function, but the static count is not reset: waiting went 3 -> 4 -> 5. Static members live for the whole program. (If tickets were cancelled, a destructor would have to decrease the count.)

## Alternative concept and complexity
| | static data member | global variable | TicketOffice object |
|---|---|---|---|
| Time to issue a seat | O(1) | O(1) | O(1) |
| Space | one counter | one counter | one counter per office (40 B object) |
| Encapsulation | private, only BusTicket can change it | anyone can change it - output: seat 1 given twice after a wrong reset | private inside TicketOffice |
| Two buses at once | **no** - one counter for the whole class | no | **yes** - output: Bus 1 issued 3, Bus 2 issued 2 |
| Extra work | none | none | office must be passed to every ticket |

For one college bus the static member is the simplest safe design. If the college runs several buses, the TicketOffice (one object per bus) is better.
