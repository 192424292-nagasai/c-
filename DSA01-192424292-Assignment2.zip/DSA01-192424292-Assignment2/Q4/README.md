# Q4 - Specifying a Class with an Array Inside It (Savings Account Mini-Statement)

## Files
| File | What it does |
|---|---|
| q4_savings_account.cpp | SavingsAccount class: private array of 10 transactions, deposit(), withdraw(), miniStatement() |
| input.txt | 14 transactions (D/W amount in rupees), 2 of them invalid |
| q4_alternatives.cpp | shifting array vs circular buffer vs std::deque, with timing for K = 10 and 50 |

Run: `./q4_savings_account < input.txt`

## Class specification
```
class SavingsAccount
 - accountNo : long long
 - balance   : long long        (paise)
 - txn[10]   : Transaction      (type, amount, balanceAfter, number)
 - count     : int
 - totalTxn  : int
 - record(type, amount) : void          (private helper, defined outside)
 + SavingsAccount(no, opening)          (defined inside)
 + getBalance() : long long             (defined inside)
 + deposit(amount) : bool               (defined outside with ::)
 + withdraw(amount) : bool              (defined outside with ::)
 + miniStatement() : void               (defined outside with ::)
```
Functions defined inside the class are automatically inline (short ones). Longer ones are defined outside with `SavingsAccount::deposit(...)`.

## Result
Opening Rs 5000, 14 lines in input.txt: `W 99999` (would go below the Rs 1000 minimum balance) and `D -50` were rejected. 12 transactions succeeded, the statement shows **the last 10 (Txn 3 to 12)**, balance Rs 13050.00. Txn 1 and 2 were discarded.

## Why the array must be private
The mini statement is a bank record. If `txn` were public, any code could change or delete a transaction (`acc.txn[0].amount = 0;`) and the statement would no longer match the balance. Keeping it private means the only way to add a transaction is through deposit()/withdraw(), which also update the balance.

## The 11th transaction: shift vs circular index
| | Shift array | Circular index |
|---|---|---|
| What happens | copy txn[1..9] to txn[0..8], put new one in txn[9] | overwrite txn[start], start = (start + 1) % 10 |
| Copies per new transaction (when full) | k - 1 = 9 | 1 |
| Time | O(k) | O(1) |
| Printing in order | simple loop 0..count-1 | loop i, read txn[(start + i) % k] |

## Design decision - last 50 transactions
Both designs only change one constant (MAX_TXN = 50). But the shifting design now copies 49 records for every transaction instead of 9, so its time grows with k. The circular buffer still does one copy. Measured (1,000,000 transactions):

| K | shift | circular | deque |
|---|---|---|---|
| 10 | 20.5 ms | 5.6 ms | 32.3 ms |
| 50 | 115.1 ms | 8.4 ms | 45.4 ms |

So the circular buffer changes least in behaviour when K grows; I chose it (it is studied further in Q7).

## Alternative concept and complexity
| | shifting fixed array | circular buffer | std::deque |
|---|---|---|---|
| Add a transaction | O(k) | O(1) | O(1) amortised (push_back + pop_front) |
| Space | k records inside the object (88 B for K=10 of long long) | k records + 1 int start | object 80 B + heap blocks of 512 B, allocated/freed while running |
| Extra memory allocation | none | none | yes (heap) |
| Code complexity | simplest | needs % when reading | simple, but uses the library |

All three printed the same last-10 list (16 ... 25 of 25 transactions).
