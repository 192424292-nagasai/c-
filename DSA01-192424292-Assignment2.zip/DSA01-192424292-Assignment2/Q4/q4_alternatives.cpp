// Q4 - Alternatives for keeping the last K transactions:
//   (1) shifting fixed array   (2) circular buffer with start index   (3) std::deque
// Same 25 transactions are added to each; the statements must be identical.
// Then the time to add 1,000,000 transactions is measured for K = 10 and K = 50.
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <deque>
#include <iostream>
using namespace std;

template <int K>
class ShiftHistory {
    long long a[K];
    int count = 0;
public:
    void add(long long x)
    {
        if (count == K) {
            for (int i = 1; i < K; i++) a[i - 1] = a[i];   // O(K)
            count--;
        }
        a[count++] = x;
    }
    int size() const { return count; }
    long long get(int i) const { return a[i]; }       // i = 0 is the oldest
};

template <int K>
class CircularHistory {
    long long a[K];
    int start = 0, count = 0;
public:
    void add(long long x)
    {
        if (count < K) a[(start + count++) % K] = x;
        else { a[start] = x; start = (start + 1) % K; }    // overwrite oldest - O(1)
    }
    int size() const { return count; }
    long long get(int i) const { return a[(start + i) % K]; }
};

template <int K>
class DequeHistory {
    deque<long long> d;
public:
    void add(long long x)
    {
        d.push_back(x);
        if ((int)d.size() > K) d.pop_front();             // O(1)
    }
    int size() const { return (int)d.size(); }
    long long get(int i) const { return d[i]; }
};

template <class H>
void fillAndPrint(const char* name, H& h)
{
    for (int t = 1; t <= 25; t++) h.add(t * 100);
    cout << name;
    for (int i = 0; i < h.size(); i++) cout << h.get(i) / 100 << ' ';
    cout << '\n';
}

template <class H>
double timeAdds(int n)
{
    H h;
    auto t1 = chrono::steady_clock::now();
    for (int i = 0; i < n; i++) h.add(i);
    auto t2 = chrono::steady_clock::now();
    volatile long long keep = h.get(0);
    (void)keep;
    return chrono::duration<double, milli>(t2 - t1).count();
}

int main()
{
    ShiftHistory<10> s; CircularHistory<10> c; DequeHistory<10> d;
    cout << "Last 10 of 25 transactions (txn numbers):\n";
    fillAndPrint("shift    : ", s);
    fillAndPrint("circular : ", c);
    fillAndPrint("deque    : ", d);

    const int N = 1000000;
    cout << "\nTime to add " << N << " transactions (ms):\n";
    cout << "K = 10 : shift " << timeAdds<ShiftHistory<10>>(N)
         << " | circular " << timeAdds<CircularHistory<10>>(N)
         << " | deque " << timeAdds<DequeHistory<10>>(N) << '\n';
    cout << "K = 50 : shift " << timeAdds<ShiftHistory<50>>(N)
         << " | circular " << timeAdds<CircularHistory<50>>(N)
         << " | deque " << timeAdds<DequeHistory<50>>(N) << '\n';

    cout << "\nSpace: shift K=10 " << sizeof(ShiftHistory<10>) << " B, circular K=10 "
         << sizeof(CircularHistory<10>) << " B, deque object " << sizeof(DequeHistory<10>)
         << " B + heap blocks (512 B each)\n";
    return 0;
}
