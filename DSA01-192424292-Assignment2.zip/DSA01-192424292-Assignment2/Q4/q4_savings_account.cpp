// Q4 - Savings Account Mini-Statement: class with an array inside it
// Keeps only the last 10 transactions (older ones are discarded by SHIFTING the array).
// Input (input.txt): D amount  or  W amount  (in rupees), one per line
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>
using namespace std;

struct Transaction {
    char type;            // 'D' deposit, 'W' withdraw
    long long amount;     // paise
    long long balanceAfter;
    int number;           // running transaction number
};

class SavingsAccount {
private:
    static const int MAX_TXN = 10;
    long long accountNo;
    long long balance;                 // paise
    Transaction txn[MAX_TXN];          // array inside the class
    int count;                         // how many are stored (0..10)
    int totalTxn;                      // how many ever happened

    void record(char type, long long amount);   // defined outside

public:
    // defined INSIDE the class (automatically inline)
    SavingsAccount(long long no, long long opening) : accountNo(no), balance(opening), count(0), totalTxn(0) {}
    long long getBalance() const { return balance; }

    // declared here, defined OUTSIDE with ::
    bool deposit(long long amount);
    bool withdraw(long long amount);
    void miniStatement() const;
};

void SavingsAccount::record(char type, long long amount)
{
    totalTxn++;
    if (count == MAX_TXN) {
        // 11th transaction: shift everything one place left, oldest is lost - O(k)
        for (int i = 1; i < MAX_TXN; i++)
            txn[i - 1] = txn[i];
        count--;
    }
    txn[count] = {type, amount, balance, totalTxn};
    count++;
}

bool SavingsAccount::deposit(long long amount)
{
    if (amount <= 0) return false;
    balance += amount;
    record('D', amount);
    return true;
}

bool SavingsAccount::withdraw(long long amount)
{
    const long long MIN_BAL = 100000;      // Rs 1000 minimum balance (assumption)
    if (amount <= 0 || balance - amount < MIN_BAL) return false;
    balance -= amount;
    record('W', amount);
    return true;
}

void SavingsAccount::miniStatement() const
{
    cout << "------ MINI STATEMENT  A/c " << accountNo << " ------\n";
    cout << left << setw(6) << "Txn" << setw(10) << "Type" << right << setw(12) << "Amount"
         << setw(14) << "Balance" << '\n';
    for (int i = 0; i < count; i++) {
        cout << left << setw(6) << txn[i].number << setw(10)
             << (txn[i].type == 'D' ? "Deposit" : "Withdraw") << right
             << setw(12) << fixed << setprecision(2) << txn[i].amount / 100.0
             << setw(14) << txn[i].balanceAfter / 100.0 << '\n';
    }
    cout << "Available balance: Rs " << balance / 100.0 << "\n";
    cout << "(showing last " << count << " of " << totalTxn << " transactions)\n";
}

int main()
{
    SavingsAccount acc(1234567890, 500000);    // opening Rs 5000
    char type;
    long long rupees;
    int line = 0;
    while (cin >> type >> rupees) {
        line++;
        bool ok = (type == 'D') ? acc.deposit(rupees * 100) : acc.withdraw(rupees * 100);
        if (!ok) cout << "Line " << line << ": " << type << " " << rupees << " REJECTED\n";
    }
    acc.miniStatement();
    // acc.balance = 0;     // compile error - balance is private
    // acc.txn[0].amount=0; // compile error - array is private, statement cannot be faked
    cout << "sizeof(SavingsAccount) = " << sizeof(SavingsAccount) << " bytes\n";
    return 0;
}
