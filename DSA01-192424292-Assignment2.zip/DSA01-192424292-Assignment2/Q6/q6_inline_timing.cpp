// Q6 - Growth investigation: 10,000,000 calls of minutesBetween + earlier
// Four designs: friend inline, friend NOT inline (noinline), member functions, public getters.
// Compile twice:
//   g++ -std=c++17 -Wall -Wextra -O0 q6_inline_timing.cpp -o q6_O0
//   g++ -std=c++17 -Wall -Wextra -O2 q6_inline_timing.cpp -o q6_O2
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
using namespace std;

class Time {
    int h, m;
public:
    Time(int hh = 0, int mm = 0) : h(hh), m(mm) {}
    // friends
    friend inline int minutesBetweenInline(const Time& a, const Time& b);
    friend inline bool earlierInline(const Time& a, const Time& b);
    friend int minutesBetweenNoInline(const Time& a, const Time& b);
    friend bool earlierNoInline(const Time& a, const Time& b);
    // members
    int minutesTo(const Time& b) const
    {
        int d = (h * 60 + m) - (b.h * 60 + b.m);
        return d < 0 ? -d : d;
    }
    bool isEarlier(const Time& b) const { return h * 60 + m < b.h * 60 + b.m; }
    // getters
    int getH() const { return h; }
    int getM() const { return m; }
};

inline int minutesBetweenInline(const Time& a, const Time& b)
{
    int d = (a.h * 60 + a.m) - (b.h * 60 + b.m);
    return d < 0 ? -d : d;
}
inline bool earlierInline(const Time& a, const Time& b) { return a.h * 60 + a.m < b.h * 60 + b.m; }

__attribute__((noinline)) int minutesBetweenNoInline(const Time& a, const Time& b)
{
    int d = (a.h * 60 + a.m) - (b.h * 60 + b.m);
    return d < 0 ? -d : d;
}
__attribute__((noinline)) bool earlierNoInline(const Time& a, const Time& b)
{
    return a.h * 60 + a.m < b.h * 60 + b.m;
}

// getter version written outside the class
inline int minutesWithGetters(const Time& a, const Time& b)
{
    int d = (a.getH() * 60 + a.getM()) - (b.getH() * 60 + b.getM());
    return d < 0 ? -d : d;
}
inline bool earlierWithGetters(const Time& a, const Time& b)
{
    return a.getH() * 60 + a.getM() < b.getH() * 60 + b.getM();
}

const int N = 10000000;
const int T = 1024;
Time times[T];

template <class F>
void measure(const char* name, F f)
{
    long long sum = 0;
    auto t1 = chrono::steady_clock::now();
    for (int i = 0; i < N; i++) sum += f(times[i & (T - 1)], times[(i * 7 + 3) & (T - 1)]);
    auto t2 = chrono::steady_clock::now();
    double ms = chrono::duration<double, milli>(t2 - t1).count();
    cout << name << ms << " ms  (" << ms * 1e6 / N << " ns/call, check " << sum << ")\n";
}

int main()
{
#ifdef __OPTIMIZE__
    cout << "Build: optimised (-O2)\n";
#else
    cout << "Build: not optimised (-O0)\n";
#endif
    for (int i = 0; i < T; i++) times[i] = Time((i * 13) % 24, (i * 29) % 60);

    measure("friend inline     : ", [](const Time& a, const Time& b) { return minutesBetweenInline(a, b) + earlierInline(a, b); });
    measure("friend noinline   : ", [](const Time& a, const Time& b) { return minutesBetweenNoInline(a, b) + earlierNoInline(a, b); });
    measure("member functions  : ", [](const Time& a, const Time& b) { return a.minutesTo(b) + a.isEarlier(b); });
    measure("public getters    : ", [](const Time& a, const Time& b) { return minutesWithGetters(a, b) + earlierWithGetters(a, b); });
    return 0;
}
