// Q6 - What is lost if h and m are made public instead of using friends
// Name: J.Nagasai   Reg No: 192424292
#include <iostream>

struct PublicTime {
    int h, m;        // public - no checks possible
};

class SafeTime {
    int h, m;
public:
    SafeTime(int hh, int mm) : h(0), m(0)
    {
        if (hh >= 0 && hh < 24 && mm >= 0 && mm < 60) { h = hh; m = mm; }
    }
    friend int minutesOfDay(const SafeTime& t) { return t.h * 60 + t.m; }
};

int main()
{
    PublicTime p{9, 45};
    p.m = 75;            // impossible time, but allowed
    p.h = -3;
    std::cout << "PublicTime after outside change: " << p.h << ":" << p.m
              << " -> minutes of day = " << p.h * 60 + p.m << " (nonsense)\n";

    SafeTime s(25, 75);  // invalid input is refused by the constructor
    std::cout << "SafeTime(25,75) stored as minutes of day = " << minutesOfDay(s)
              << " (rejected, kept 00:00)\n";
    // s.h = 30;         // compile error - private
    return 0;
}
