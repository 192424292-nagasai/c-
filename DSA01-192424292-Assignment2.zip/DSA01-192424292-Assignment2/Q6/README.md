# Q6 - Friend Functions and Inline Functions (Train Journey Planner)

## Files
| File | What it does |
|---|---|
| q6_complete.cpp | Complete-the-Code, TODO 1 and TODO 2 filled |
| q6_tests.cpp | correctness tests read from input.txt |
| input.txt | 7 test pairs: h1 m1 h2 m2 expectedMinutes expectedEarlier |
| q6_inline_timing.cpp | 10,000,000 calls: friend inline, friend noinline, member functions, getters - built at -O0 and -O2 |
| q6_public_members.cpp | what is lost if h and m were public |

Run:
```
./q6_tests < input.txt
g++ -std=c++17 -Wall -Wextra -O0 q6_inline_timing.cpp -o q6_inline_timing_O0 && ./q6_inline_timing_O0
g++ -std=c++17 -Wall -Wextra -O2 q6_inline_timing.cpp -o q6_inline_timing_O2 && ./q6_inline_timing_O2
```

## Complete the Code
```cpp
// TODO 1
int diff = (a.h * 60 + a.m) - (b.h * 60 + b.m);
return diff < 0 ? -diff : diff;
// TODO 2
return a.h * 60 + a.m < b.h * 60 + b.m;
```
Expected `205 false`, actual `205 false`.

## Correctness check (verified by hand)
| A | B | Hand working | minutes | earlier(A,B) | Result |
|---|---|---|---|---|---|
| 09:45 | 13:10 | 790 - 585 | 205 | true | PASS |
| 13:10 | 09:45 | same, order swapped | 205 | false | PASS |
| 12:00 | 12:00 | same time twice | 0 | false | PASS |
| 11:59 | 12:01 | either side of noon: 721 - 719 | 2 | true | PASS |
| 12:30 | 11:30 | 750 - 690 | 60 | false | PASS |
| 00:00 | 23:59 | 1439 - 0 | 1439 | true | PASS |
| 06:15 | 18:15 | 1095 - 375 | 720 | true | PASS |

7 / 7 passed.

## Why a friend function
`minutesBetween(a, b)` and `earlier(a, b)` use two Time objects **equally**. As a member, one time becomes special (`a.minutesTo(b)`), which reads oddly for a symmetric operation. A friend is a normal function that has been given access to the private h and m.

| | member function | friend function |
|---|---|---|
| Call | `a.minutesTo(b)` | `minutesBetween(a, b)` |
| `this` pointer | yes | no |
| Access | private members of its class | private members of every class that declares it friend |
| Declared | in the class | `friend` line in the class, body outside |
| Inherited | yes | no |

## What inline actually asks
`inline` asks the compiler to put the function body at the call site instead of making a call (no jump, no stack frame). It is only a **hint**: the compiler decides. At -O0 it never inlines; at -O2 it inlines small functions even without the keyword. (inline also allows the definition to appear in several files, e.g. in a header.)

## Growth investigation - 10,000,000 calls
| Design | -O0 | -O2 |
|---|---|---|
| friend inline | 95.4 ms (9.5 ns/call) | 19.4 ms (1.9 ns/call) |
| friend noinline | 112.9 ms (11.3 ns/call) | 33.8 ms (3.4 ns/call) |
| member functions | 171.8 ms (17.2 ns/call) | 18.7 ms (1.9 ns/call) |
| public getters | 169.1 ms (16.9 ns/call) | 18.8 ms (1.9 ns/call) |

Explanation:
- At **-O0** nothing is inlined, so every version pays for real function calls. The getter version makes 4 extra getter calls per comparison, and the member version was about as slow in my run. -O0 timings vary between runs, so I only compare large differences there.
- At **-O2** the inline friend, member and getter versions all become the same machine code (about 1.9 ns). Only the version forced `noinline` stays slower (3.4 ns) because it still pays for the call.
- So `inline` itself made little difference; the **optimisation level** did. The keyword does not force anything.

## What is lost if h and m were public
q6_public_members: outside code set a time to `-3:75`, giving -105 minutes of the day. With private members the constructor rejected `SafeTime(25, 75)`. Public members lose validation, and every program using `t.h` must change if the class later stores minutes-of-day instead.

## Deployment decision
**Keep the friend functions.** At -O2 they are as fast as member functions and getters (all ~1.9 ns per call); they read naturally for a two-object operation (`earlier(dep, arr)`); and they keep h and m private, so only these two named functions can see them. Getters would expose the representation to every user of the class.

## Alternative concept and complexity
| | friend functions | member functions | public getters |
|---|---|---|---|
| Time per call | O(1) | O(1) | O(1) |
| Measured -O0 / -O2 | 9.5 / 1.9 ns | 17.2 / 1.9 ns | 16.9 / 1.9 ns |
| Encapsulation | private, only the listed friends can read | private, only members | anyone can read h and m (not write) |
| Symmetry of call | `earlier(a, b)` | `a.isEarlier(b)` | `earlier(a, b)` using getters |
