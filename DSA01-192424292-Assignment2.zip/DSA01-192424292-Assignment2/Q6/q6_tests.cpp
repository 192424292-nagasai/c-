// Q6 - Correctness check of the friend functions
// Input (input.txt): h1 m1 h2 m2 expectedMinutes expectedEarlier(1/0)
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>
using namespace std;

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend inline int minutesBetween(const Time& a, const Time& b);
    friend inline bool earlier(const Time& a, const Time& b);
    friend ostream& operator<<(ostream& out, const Time& t);
};

inline int minutesBetween(const Time& a, const Time& b)
{
    int diff = (a.h * 60 + a.m) - (b.h * 60 + b.m);
    return diff < 0 ? -diff : diff;
}

inline bool earlier(const Time& a, const Time& b)
{
    return a.h * 60 + a.m < b.h * 60 + b.m;
}

ostream& operator<<(ostream& out, const Time& t)
{
    return out << setw(2) << setfill('0') << t.h << ':' << setw(2) << t.m << setfill(' ');
}

int main()
{
    int h1, m1, h2, m2, expMin, expEarly;
    int pass = 0, total = 0;
    cout << "A      B      minutes(exp/got)  earlier(A,B)(exp/got)  result\n";
    while (cin >> h1 >> m1 >> h2 >> m2 >> expMin >> expEarly) {
        Time a(h1, m1), b(h2, m2);
        int gotMin = minutesBetween(a, b);
        bool gotEarly = earlier(a, b);
        bool ok = gotMin == expMin && gotEarly == (expEarly == 1);
        total++;
        if (ok) pass++;
        cout << a << "  " << b << "  " << setw(6) << expMin << " / " << setw(4) << gotMin
             << "        " << setw(5) << (expEarly ? "true" : "false") << " / " << setw(5)
             << boolalpha << gotEarly << noboolalpha << "      " << (ok ? "PASS" : "FAIL") << '\n';
    }
    cout << pass << " / " << total << " tests passed\n";
    return 0;
}
