// Task 12 - Day-4 Design Challenge: MODIFIED design
// New rules: 4th zone Airport (Rs 60), 10% weekend discount (NOT combined with
// peak surcharge), monthly pass = unlimited journeys inside two chosen zones.
// Design: fare table indexed by zone + separate DiscountRule + Pass class.
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

// ---------------- constants (one place) ----------------
enum class Zone { Inner, Middle, Outer, Airport };          // Airport added
constexpr int ZONE_COUNT = 4;
constexpr long long FARE_PAISE[ZONE_COUNT] = {1000, 2000, 3000, 6000};
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr int WEEKEND_DISCOUNT_PERCENT = 10;
constexpr int STUDENT_CONCESSION_PERCENT = 15;
constexpr int SENIOR_CONCESSION_PERCENT = 50;
constexpr long long MIN_BALANCE_PAISE = 5000;
const string ZONE_NAME[ZONE_COUNT] = {"Inner", "Middle", "Outer", "Airport"};
// --------------------------------------------------------

enum class PassengerType { Adult, Student, Senior };
enum class Day { Mon, Tue, Wed, Thu, Fri, Sat, Sun };

struct Journey {
    Zone from, to;
    Day day;
    int hour, minute;
    int year, month;
    PassengerType type;
    Zone farthest() const { return static_cast<int>(from) > static_cast<int>(to) ? from : to; }
};

// separate rule for time-based adjustment: weekend discount OR peak surcharge, never both
class TimeRule {
public:
    static bool isWeekend(Day d) { return d == Day::Sat || d == Day::Sun; }
    static bool isPeak(int h, int m)
    {
        int t = h * 60 + m;
        return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
    }
    static long long apply(long long base, const Journey& j)
    {
        if (isWeekend(j.day)) return base - base * WEEKEND_DISCOUNT_PERCENT / 100;
        if (isPeak(j.hour, j.minute)) return base + base * PEAK_SURCHARGE_PERCENT / 100;
        return base;
    }
};

class FareCalculator {
public:
    static long long fare(const Journey& j)
    {
        long long f = FARE_PAISE[static_cast<int>(j.farthest())];   // table, no switch
        f = TimeRule::apply(f, j);
        if (j.type == PassengerType::Student) f -= f * STUDENT_CONCESSION_PERCENT / 100;
        if (j.type == PassengerType::Senior)  f -= f * SENIOR_CONCESSION_PERCENT / 100;
        return f;
    }
};

// new class: monthly pass for two chosen zones
class MonthlyPass {
    Zone z1, z2;
    int year, month;
public:
    MonthlyPass(Zone a, Zone b, int y, int m) : z1(a), z2(b), year(y), month(m) {}
    bool coversZone(Zone z) const { return z == z1 || z == z2; }
    bool covers(const Journey& j) const
    {
        return j.year == year && j.month == month && coversZone(j.from) && coversZone(j.to);
    }
};

class SmartCard {
    long long balance;
    const MonthlyPass* pass;    // nullptr if no pass
public:
    explicit SmartCard(long long b, const MonthlyPass* p = nullptr) : balance(b < 0 ? 0 : b), pass(p) {}
    long long getBalance() const { return balance; }
    bool canTravel(long long f) const { return f >= 0 && balance - f >= MIN_BALANCE_PAISE; }
    // returns fare charged, or -1 if denied
    long long travel(const Journey& j)
    {
        if (pass != nullptr && pass->covers(j)) return 0;       // pass journey is free
        long long f = FareCalculator::fare(j);
        if (!canTravel(f)) return -1;
        balance -= f;
        return f;
    }
};

string rs(long long p)
{
    if (p < 0) return "DENIED";
    string s = to_string(p / 100) + ".";
    if (p % 100 < 10) s += "0";
    return s + to_string(p % 100);
}

int passed = 0, failed = 0;

void check(const string& name, long long expected, long long actual)
{
    bool ok = expected == actual;
    ok ? passed++ : failed++;
    cout << left << setw(48) << name << right << setw(9) << rs(expected) << setw(9) << rs(actual)
         << "  " << (ok ? "PASS" : "FAIL") << "\n";
}

int main()
{
    using Z = Zone; using D = Day; using P = PassengerType;

    cout << "PART 1 - fare tests (Rs)\n";
    cout << left << setw(48) << "Case" << right << setw(9) << "Expected" << setw(9) << "Actual" << "  Result\n";
    cout << string(74, '-') << "\n";
    struct T { string name; Journey j; long long expected; };
    T tests[] = {
        {"Old rule kept: Inner weekday off-peak",        {Z::Inner, Z::Inner, D::Mon, 11, 0, 2026, 11, P::Adult}, 1000},
        {"Old rule kept: Outer weekday peak 09:00",      {Z::Inner, Z::Outer, D::Tue,  9, 0, 2026, 11, P::Adult}, 3600},
        {"Airport weekday off-peak",                     {Z::Inner, Z::Airport, D::Wed, 12, 0, 2026, 11, P::Adult}, 6000},
        {"Airport weekday peak 18:00",                   {Z::Airport, Z::Middle, D::Thu, 18, 0, 2026, 11, P::Adult}, 7200},
        {"Airport Saturday 09:00 (discount, no peak)",   {Z::Inner, Z::Airport, D::Sat,  9, 0, 2026, 11, P::Adult}, 5400},
        {"Middle Sunday off-peak (discount)",            {Z::Middle, Z::Inner, D::Sun, 13, 0, 2026, 11, P::Adult}, 1800},
        {"Outer Sunday 18:00 (discount, no peak)",       {Z::Outer, Z::Outer, D::Sun, 18, 0, 2026, 11, P::Adult}, 2700},
        {"Airport Saturday student",                     {Z::Airport, Z::Inner, D::Sat, 12, 0, 2026, 11, P::Student}, 4590},
        {"Airport weekday peak senior",                  {Z::Airport, Z::Inner, D::Fri,  8, 0, 2026, 11, P::Senior}, 3600},
        {"Friday 19:59 Outer still peak",                {Z::Outer, Z::Inner, D::Fri, 19, 59, 2026, 11, P::Adult}, 3600},
    };
    for (const T& t : tests) check(t.name, t.expected, FareCalculator::fare(t.j));

    cout << "\nPART 2 - monthly pass (Inner + Middle, Nov 2026), card Rs 100\n";
    cout << string(74, '-') << "\n";
    MonthlyPass pass(Z::Inner, Z::Middle, 2026, 11);
    SmartCard card(10000, &pass);
    check("Inner->Middle peak, inside pass zones",  0, card.travel({Z::Inner, Z::Middle, D::Mon, 9, 0, 2026, 11, P::Adult}));
    check("Middle->Middle Sunday, inside pass",     0, card.travel({Z::Middle, Z::Middle, D::Sun, 12, 0, 2026, 11, P::Adult}));
    check("Inner->Outer, outside pass -> pays",  3000, card.travel({Z::Inner, Z::Outer, D::Tue, 12, 0, 2026, 11, P::Adult}));
    check("  balance after (10000-3000)",        7000, card.getBalance());
    check("Inner->Middle in December, pass expired", 2000, card.travel({Z::Inner, Z::Middle, D::Tue, 12, 0, 2026, 12, P::Adult}));
    check("Airport off-peak -> 6000 would leave Rs -10", -1, card.travel({Z::Inner, Z::Airport, D::Wed, 12, 0, 2026, 11, P::Adult}));
    check("  balance unchanged",                 5000, card.getBalance());

    cout << "\nFare table now (adult):\n";
    for (int z = 0; z < ZONE_COUNT; z++) {
        Journey wk{Z::Inner, static_cast<Zone>(z), D::Mon, 12, 0, 2026, 11, P::Adult};
        Journey pk{Z::Inner, static_cast<Zone>(z), D::Mon, 9, 0, 2026, 11, P::Adult};
        Journey we{Z::Inner, static_cast<Zone>(z), D::Sat, 9, 0, 2026, 11, P::Adult};
        cout << "  " << left << setw(8) << ZONE_NAME[z] << right << " weekday Rs " << setw(6) << rs(FareCalculator::fare(wk))
             << "  peak Rs " << setw(6) << rs(FareCalculator::fare(pk))
             << "  weekend Rs " << setw(6) << rs(FareCalculator::fare(we)) << "\n";
    }
    cout << "\nsizeof(SmartCard) = " << sizeof(SmartCard) << " bytes, sizeof(MonthlyPass) = "
         << sizeof(MonthlyPass) << " bytes\n";
    cout << passed << " passed, " << failed << " failed\n";
    return failed == 0 ? 0 : 1;
}
