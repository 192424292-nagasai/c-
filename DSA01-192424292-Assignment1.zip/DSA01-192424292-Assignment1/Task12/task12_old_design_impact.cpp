// Task 12 - Impact on the ORIGINAL switch design (from Task 6)
// Only the enum got a new value "Airport". The switch was not updated.
// -Wall gives "enumeration value 'Airport' not handled in switch"
// and the Airport fare silently becomes 0 -> free airport trips!
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>

enum class Zone { Inner, Middle, Outer, Airport };
constexpr int BASE_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_SURCHARGE_PERCENT = 20;

long long fare(Zone z, bool peak)
{
    long long base = 0;
    switch (z) {
        case Zone::Inner:  base = BASE_PAISE[0]; break;
        case Zone::Middle: base = BASE_PAISE[1]; break;
        case Zone::Outer:  base = BASE_PAISE[2]; break;
    }
    if (peak) base += base * PEAK_SURCHARGE_PERCENT / 100;
    return base;
}

int main()
{
    std::cout << "Outer off-peak  : " << fare(Zone::Outer, false) << " paise\n";
    std::cout << "Airport off-peak: " << fare(Zone::Airport, false) << " paise  (should be 6000)\n";
    std::cout << "Airport peak    : " << fare(Zone::Airport, true) << " paise  (should be 7200)\n";
    // weekend: original fare(Zone, bool peak) has no day parameter at all,
    // so the weekend discount cannot be added without changing the function signature.
    return 0;
}
