# Task 12 - Day-4 Design Challenge: Re-evaluate and Adapt the Design

Changed requirement: 4th zone **Airport (Rs 60)**, **10% weekend discount** that does not combine with the peak surcharge, and a **monthly pass** with unlimited journeys in two chosen zones.

## Files
| File | What it does |
|---|---|
| task12_old_design_impact.cpp | original Task 6 switch design with only `Airport` added to the enum - shows the problem |
| task12_redesign.cpp | modified design: fare table indexed by zone, TimeRule (weekend OR peak), MonthlyPass class, SmartCard with pass, 17 tests |

No input file is needed (test cases are in a table inside the program).

## A. Impact analysis
| Part of original design | Affected? | Change needed |
|---|---|---|
| `enum class Zone` | yes | add `Airport` |
| `BASE_PAISE[]` | yes | add 6000 |
| `switch (z)` in fare() | yes | new case - if forgotten, Airport fare = 0 |
| `fare(Zone, bool peak)` signature | yes | no day of the week, cannot know weekend |
| peak expression | yes | must not apply on weekends |
| SmartCard | partly | needs to know about a pass |
| journey | yes | needs from-zone and to-zone (pass check) and date |
| MIN_BALANCE, concession % | no | unchanged |

## B. Evaluation of the original design (worked examples)
- Adding only `Airport` to the enum: g++ warned *enumeration value 'Airport' not handled in switch*, and the program printed **Airport off-peak: 0 paise** (should be 6000) - free airport trips.
- Saturday 9 AM Airport: the old fare(zone, peak) would give 6000 + 20% = 7200, but the correct answer is 6000 - 10% = **5400**. The old function has no day parameter, so it cannot be fixed without changing its signature.
- Monthly pass: SmartCard only has a balance, it cannot say "this journey is free".

So the switch cannot absorb the change safely; the SmartCard class can be kept with a small addition.

## Decision: MODIFY (not full redesign)
Kept: paise in long long, constants in one place, private balance + Rs 50 rule, peak rule.
Changed:
- switch -> `FARE_PAISE[ZONE_COUNT]` table indexed by zone (Airport = one new value).
- New `TimeRule::apply()` - weekend discount OR peak surcharge, never both.
- New `MonthlyPass` class (two zones + month/year), SmartCard holds a pointer to an optional pass.
- `Journey` now has from, to, day, time, month, year, passenger type; fare uses the farthest zone.

## C. Revised fare table (adult)
| Zone | Weekday off-peak | Weekday peak | Weekend (any time) |
|---|---|---|---|
| Inner | Rs 10.00 | Rs 12.00 | Rs 9.00 |
| Middle | Rs 20.00 | Rs 24.00 | Rs 18.00 |
| Outer | Rs 30.00 | Rs 36.00 | Rs 27.00 |
| Airport | Rs 60.00 | Rs 72.00 | Rs 54.00 |

## D. Test results (17 passed, 0 failed)
| Case | Expected | Actual |
|---|---|---|
| Old rule: Inner weekday off-peak | 10.00 | 10.00 |
| Old rule: Outer weekday peak 09:00 | 36.00 | 36.00 |
| Airport weekday off-peak | 60.00 | 60.00 |
| Airport weekday peak 18:00 | 72.00 | 72.00 |
| Airport Saturday 09:00 (discount, no peak) | 54.00 | 54.00 |
| Middle Sunday off-peak | 18.00 | 18.00 |
| Outer Sunday 18:00 (discount, no peak) | 27.00 | 27.00 |
| Airport Saturday student | 45.90 | 45.90 |
| Airport weekday peak senior | 36.00 | 36.00 |
| Friday 19:59 Outer (still peak) | 36.00 | 36.00 |
| Pass Inner+Middle: Inner->Middle peak | 0.00 | 0.00 |
| Pass: Middle->Middle Sunday | 0.00 | 0.00 |
| Pass: Inner->Outer (outside pass) | 30.00 | 30.00 |
| Pass expired (December) | 20.00 | 20.00 |
| Airport Rs 60 on Rs 50 card | DENIED | DENIED |

## Evidence-based defence
- All old fares are unchanged (regression tests pass), so the change is safe.
- New zone = one constant, not a new switch case; forgetting it is impossible because the table size is `ZONE_COUNT`.
- The weekend/peak rule is in one function, so "do not combine" is enforced in one place.
- Pass logic is in its own class, so SmartCard only gained one pointer (16 bytes now, was 8).
- Time per journey is still O(1); space is O(z) for the fare table + O(1) per pass.
- Trade-off: a bit more code (3 small classes) than the first version, but each rule now lives in one place.

Assumptions: concession is applied after the weekend discount; a pass covers a journey only if both start and end zones are in the pass; Airport is the farthest zone.
