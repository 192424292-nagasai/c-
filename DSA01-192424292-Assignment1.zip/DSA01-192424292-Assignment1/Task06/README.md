# Task 6 - Design the Control Structures

## Files
| File | What it does |
|---|---|
| task6_complete.cpp | Complete-the-Code program with TODO 1 and TODO 2 filled |
| task6_peak_boundary.cpp | journeys at exactly 8:00, 10:00, 17:00, 20:00 etc., uses while / break / continue / switch |
| input.txt | input for task6_peak_boundary (zone hour minute, -1 = end) |
| task6_array_version.cpp | alternative: fare from an array indexed by zone, with 4th zone and timing |

Run: `./task6_peak_boundary < input.txt`

## Pseudocode (SIMATS standard style)
```
ALGORITHM ComputeFare
INPUT  : zone, hour, minute, balance
OUTPUT : fare in paise, or DENIED
BEGIN
    IF zone < 0 OR zone > 2 OR hour NOT IN 0..23 OR minute NOT IN 0..59 THEN
        DISPLAY "invalid journey"
        RETURN
    END IF
    t <- hour * 60 + minute
    CASE zone OF
        Inner  : base <- 1000
        Middle : base <- 2000
        Outer  : base <- 3000
    END CASE
    IF (t >= 480 AND t < 600) OR (t >= 1020 AND t < 1200) THEN
        base <- base + base * 20 / 100
    END IF
    IF balance - base >= 5000 THEN
        balance <- balance - base
        DISPLAY base, balance
    ELSE
        DISPLAY "Denied (low balance)"
    END IF
END

ALGORITHM ProcessDay
BEGIN
    WHILE more journeys DO
        READ zone
        IF zone = -1 THEN BREAK
        READ hour, minute
        IF journey invalid THEN CONTINUE
        CALL ComputeFare
    END WHILE
END
```

## Completed TODOs
```cpp
// TODO 1
long long base = 0;
switch (z) {
    case Zone::Inner:  base = BASE_PAISE[0]; break;
    case Zone::Middle: base = BASE_PAISE[1]; break;
    case Zone::Outer:  base = BASE_PAISE[2]; break;
}
if (peak) base += base * PEAK_SURCHARGE_PERCENT / 100;
return base;

// TODO 2
return balance - f >= MIN_BALANCE_PAISE;
```

## Output vs expected
| Expected | Actual |
|---|---|
| Fare Rs 10.00 balance Rs 90 | Fare Rs 10.00 balance Rs 90 |
| Fare Rs 36.00 balance Rs 54 | Fare Rs 36.00 balance Rs 54 |
| Denied (low balance) balance Rs 54 | Denied (low balance) balance Rs 54 |

Matches exactly.

## 10 AM and 8 PM check (task6_peak_boundary)
| Time | Result |
|---|---|
| 07:59 | off-peak |
| 08:00 | PEAK |
| 09:59 | PEAK |
| 10:00 | off-peak (correct) |
| 16:59 | off-peak |
| 17:00 | PEAK |
| 19:59 | PEAK |
| 20:00 | off-peak (correct) |
| zone 5, hour 25 | skipped with `continue` |

## Choice of control structures
- if-else: for ranges (peak time, balance check).
- switch: for the zone, because it is one value with fixed cases. With enum class and no `default`, g++ -Wall warns when a zone is missing (see Task 12).
- ?: for small choices inside output (`peak ? "PEAK" : "OFF-PEAK"`).
- Loops: range-based for is best for a fixed array of trips (no index mistakes); while is best when reading until end of input; normal for when we need the index.
- break: stop at the end-of-day marker -1. continue: skip an invalid journey.
- If no case of a switch matches and there is no default, nothing in the switch runs, so `base` stays 0 - a free journey. That is why the input is validated first and `default: return -1;` is used in the boundary program.

## Alternative concept and complexity: array instead of switch
| | switch | array FARE[] |
|---|---|---|
| Time per lookup | O(1) (compiler can make a jump table) | O(1), one index |
| Measured 100 million lookups | 516.7 ms | 360.6 ms |
| Space | code only | 8 bytes per zone (32 bytes for 4 zones) |
| Adding a 4th zone | add a new case by hand (easy to forget) | add one value to the array |
