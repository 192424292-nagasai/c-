// Task 6 - Alternative: base fare looked up from an array indexed by zone
// instead of a switch. Also times both versions.
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>

enum class Zone { Inner, Middle, Outer, Airport };   // 4th zone added to show the effect
constexpr long long FARE[] = {1000, 2000, 3000, 6000};  // just add one value
constexpr int PEAK_SURCHARGE_PERCENT = 20;

long long fareArray(Zone z, bool peak)
{
    long long base = FARE[static_cast<int>(z)];
    if (peak) base += base * PEAK_SURCHARGE_PERCENT / 100;
    return base;
}

long long fareSwitch(Zone z, bool peak)
{
    long long base = 0;
    switch (z) {
        case Zone::Inner:  base = 1000; break;
        case Zone::Middle: base = 2000; break;
        case Zone::Outer:  base = 3000; break;
        case Zone::Airport: base = 6000; break;   // a new case must be written by hand
    }
    if (peak) base += base * PEAK_SURCHARGE_PERCENT / 100;
    return base;
}

int main()
{
    for (int i = 0; i < 4; i++) {
        Zone z = static_cast<Zone>(i);
        std::cout << "Zone " << i << " off-peak array=" << fareArray(z, false)
                  << " switch=" << fareSwitch(z, false)
                  << " | peak array=" << fareArray(z, true)
                  << " switch=" << fareSwitch(z, true) << '\n';
    }

    const int N = 100000000;
    volatile long long sink = 0;
    auto t1 = std::chrono::high_resolution_clock::now();
    for (int n = 0; n < N; n++) sink = sink + fareSwitch(static_cast<Zone>(n & 3), n & 4);
    auto t2 = std::chrono::high_resolution_clock::now();
    for (int n = 0; n < N; n++) sink = sink + fareArray(static_cast<Zone>(n & 3), n & 4);
    auto t3 = std::chrono::high_resolution_clock::now();
    std::cout << "\n100 million lookups, switch: "
              << std::chrono::duration<double, std::milli>(t2 - t1).count() << " ms\n";
    std::cout << "100 million lookups, array : "
              << std::chrono::duration<double, std::milli>(t3 - t2).count() << " ms\n";
    std::cout << "Space of FARE array = " << sizeof(FARE) << " bytes\n";
    return 0;
}
