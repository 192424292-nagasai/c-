// Task 6 - Extra: journeys at exactly 10 AM and 8 PM (and other boundaries)
// peak is decided from the time, using if-else / ?: / switch / loops with continue and break
// Input is read from input.txt :  zone(0/1/2) hour minute   ; line "-1" ends the day
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>

enum class Zone { Inner, Middle, Outer };
constexpr int BASE_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;

bool isPeak(int hour, int minute)
{
    int t = hour * 60 + minute;
    return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
}

long long fare(Zone z, bool peak)
{
    long long base = 0;
    switch (z) {
        case Zone::Inner:  base = BASE_PAISE[0]; break;
        case Zone::Middle: base = BASE_PAISE[1]; break;
        case Zone::Outer:  base = BASE_PAISE[2]; break;
        default:           return -1;     // no case matched -> invalid
    }
    if (peak) base += base * PEAK_SURCHARGE_PERCENT / 100;
    return base;
}

int main()
{
    long long balance = 100000;   // Rs 1000 so that balance is not the issue here
    int zoneNo, hour, minute;
    int count = 0;

    while (std::cin >> zoneNo) {
        if (zoneNo == -1) break;                  // end of day marker
        std::cin >> hour >> minute;
        count++;
        if (zoneNo < 0 || zoneNo > 2 || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            std::cout << "Journey " << count << ": invalid data, skipped\n";
            continue;                              // skip invalid journey
        }
        bool peak = isPeak(hour, minute);
        long long f = fare(static_cast<Zone>(zoneNo), peak);
        balance -= f;
        std::cout << "Journey " << count << ": zone " << zoneNo << " at "
                  << std::setw(2) << std::setfill('0') << hour << ':'
                  << std::setw(2) << minute << std::setfill(' ')
                  << (peak ? "  PEAK    " : "  OFF-PEAK") << "  fare Rs "
                  << f / 100 << '.' << std::setw(2) << std::setfill('0') << f % 100
                  << std::setfill(' ') << '\n';
    }
    std::cout << "Balance left Rs " << balance / 100 << '.' << std::setw(2)
              << std::setfill('0') << balance % 100 << '\n';
    return 0;
}
