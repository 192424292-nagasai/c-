// Task 4 - Corrected version: every conversion written explicitly
// using brace initialisation and static_cast
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
int main()
{
    int a{7}, b{2};
    double c{static_cast<double>(a / b)};          // integer division is now visible on purpose
    double d{static_cast<double>(a) / b};          // real division
    std::cout << c << ' ' << d << '\n';

    char ch{static_cast<char>('A' + 2)};
    std::cout << ch << ' ' << static_cast<char>(ch + 1) << " (code " << static_cast<int>(ch + 1) << ")\n";

    bool flag{5 != 0};                             // say what we mean
    std::cout << flag << ' ' << std::boolalpha << flag << std::noboolalpha << '\n';

    unsigned int u{1};
    int s{-1};
    // compare as signed long long so -1 stays -1
    std::cout << (static_cast<long long>(s) < static_cast<long long>(u) ? "s < u" : "s >= u") << '\n';

    // narrowing demo - these lines do NOT compile with braces, so they are commented
    // int x{3.7};          // error: narrowing conversion of 3.7 from double to int
    // char small{300};     // error: narrowing
    int x = 3.7;            // old style: compiles, silently becomes 3 (-Wall gives no error)
    int y{static_cast<int>(3.7)};   // explicit, reader knows we cut the fraction
    std::cout << "int x = 3.7 gives " << x << ", static_cast gives " << y << '\n';

    // metro example: fare in paise from rupees
    double rupees{12.5};
    long long paise{static_cast<long long>(rupees * 100 + 0.5)};
    std::cout << "Rs 12.5 -> " << paise << " paise\n";
    return 0;
}
