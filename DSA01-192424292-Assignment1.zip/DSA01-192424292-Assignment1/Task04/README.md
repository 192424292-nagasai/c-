# Task 4 - Control Implicit Conversions

## Files
| File | What it does |
|---|---|
| task4_predict.cpp | the given Predict-the-Output program (not changed) |
| task4_fixed.cpp | same program with brace initialisation and static_cast everywhere |
| narrowing_error.cpp | expected to FAIL compiling - proves `int x{3.7};` is stopped |
| output/task4_predict_compile.txt | -Wsign-compare warning |
| output/narrowing_error_compile.txt | the narrowing errors |

No input file is needed.

## My predicted output (written before running)
```
3 3.5
C 68
1 true
s >= u
```

## Actual output
```
3 3.5
C 68
1 true
s >= u
```

## Explanation of each line
| Line | Conversion that happened |
|---|---|
| `3 3.5` | `a / b` is int / int = 3 (integer division), then 3 is converted to double 3.0, printed as `3`. In `d`, a is cast to double first so it is 7.0 / 2 = 3.5. |
| `C 68` | `'A' + 2` = 65 + 2 = 67 = 'C'. In `ch + 1` the char is promoted to int, so 68 is printed as a number, not 'D'. |
| `1 true` | `bool flag = 5` - any non-zero int becomes true. Printed as 1, then as `true` after boolalpha. |
| `s >= u` | signed vs unsigned: -1 is converted to unsigned = 4294967295, which is bigger than 1. g++ -Wall -Wextra warned: *comparison of integer expressions of different signedness*. |

Difference between prediction and actual: none. The two lines that look "wrong" (`C 68` and `s >= u`) are exactly the implicit conversions this task is about.

## Fixes (task4_fixed.cpp)
- `static_cast<char>(ch + 1)` prints `D`.
- Comparing as `long long` gives `s < u` (correct).
- `int x{3.7};` and `char c{300};` -> compile errors "narrowing conversion" (see narrowing_error_compile.txt). `int x = 3.7;` compiles and silently gives 3.
- static_cast is needed whenever we really want a conversion that loses data (double -> int, enum class -> int, signed <-> unsigned).

## Conversion points in the fare program
1. rupees (double) -> paise (long long): use `llround` / explicit cast.
2. `fare * 20 / 100` must stay in integers (no 1.2 double).
3. `enum class Zone` -> array index needs `static_cast<int>`.
4. `vector.size()` (unsigned) compared with int loop counter.
5. bool peak used in arithmetic (becomes 0/1).

## Alternative concept and complexity
If every conversion is written with static_cast and braces:
- Running time: same O(1), the casts generate the same machine code.
- Memory: same.
- Errors caught at compile time: narrowing (double -> int, int -> char, long long -> int) becomes a compile error instead of a wrong value at run time. Signed/unsigned mistakes become visible in the code.
