// Task 4 - this file is EXPECTED to fail compiling.
// It proves that brace initialisation stops narrowing conversions.
// Compile: g++ -std=c++17 -Wall -Wextra narrowing_error.cpp
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
int main()
{
    int x{3.7};          // narrowing double -> int
    char c{300};         // narrowing, 300 does not fit in char
    std::cout << x << ' ' << c << '\n';
}
