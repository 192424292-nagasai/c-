// Task 1 - Objects in the metro fare problem (OOP style)
// Name: J.Nagasai   Reg No: 192424292
// Shows the 5 objects: Zone, FareTable, Passenger, SmartCard, Journey
// and their data + behaviour.

#include <iostream>
#include <string>
using namespace std;

// Zone object - only 3 fixed values, so enum class
enum class Zone { Inner, Middle, Outer };

string zoneName(Zone z)
{
    switch (z) {
        case Zone::Inner:  return "Inner";
        case Zone::Middle: return "Middle";
        case Zone::Outer:  return "Outer";
    }
    return "Unknown";
}

// Passenger type (for concession)
enum class PassengerType { Adult, Student, Senior };

// FareTable object - data: base fares, surcharge. behaviour: baseFare(), isPeak()
class FareTable {
public:
    long long baseFare(Zone z) const
    {
        switch (z) {
            case Zone::Inner:  return 1000;   // Rs 10 in paise
            case Zone::Middle: return 2000;   // Rs 20
            case Zone::Outer:  return 3000;   // Rs 30
        }
        return 0;
    }
    bool isPeak(int hour, int minute) const
    {
        int t = hour * 60 + minute;   // minutes from midnight
        return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
    }
    long long fare(Zone z, int hour, int minute) const
    {
        long long f = baseFare(z);
        if (isPeak(hour, minute))
            f = f + f * 20 / 100;      // 20% surcharge
        return f;
    }
};

// Passenger object - data: name, type. behaviour: concessionPercent()
class Passenger {
    string name;
    PassengerType type;
public:
    Passenger(string n, PassengerType t) : name(n), type(t) {}
    string getName() const { return name; }
    int concessionPercent() const
    {
        if (type == PassengerType::Student) return 15;
        if (type == PassengerType::Senior)  return 50;
        return 0;
    }
};

// SmartCard object - data: card id, balance (private). behaviour: recharge, canTravel, deduct
class SmartCard {
    int cardId;
    long long balance;   // paise, kept private so nobody can make it negative
public:
    SmartCard(int id, long long b) : cardId(id), balance(b) {}
    long long getBalance() const { return balance; }
    int getId() const { return cardId; }
    bool recharge(long long amount)
    {
        if (amount <= 0) return false;
        balance += amount;
        return true;
    }
    bool canTravel(long long f) const { return balance - f >= 5000; }  // Rs 50 must remain
    bool deduct(long long f)
    {
        if (!canTravel(f)) return false;
        balance -= f;
        return true;
    }
};

// Journey object - data: zone, time, passenger. behaviour: computeFare()
class Journey {
    Zone zone;
    int hour, minute;
public:
    Journey(Zone z, int h, int m) : zone(z), hour(h), minute(m) {}
    long long computeFare(const FareTable& table, const Passenger& p) const
    {
        long long f = table.fare(zone, hour, minute);
        f = f - f * p.concessionPercent() / 100;
        return f;
    }
    Zone getZone() const { return zone; }
    int getHour() const { return hour; }
    int getMinute() const { return minute; }
};

void printRs(long long paise)
{
    cout << "Rs " << paise / 100 << "." << (paise % 100 < 10 ? "0" : "") << paise % 100;
}

int main()
{
    FareTable table;
    Passenger p1("Ravi", PassengerType::Adult);
    Passenger p2("Priya", PassengerType::Student);
    SmartCard card(101, 10000);   // Rs 100

    Journey j1(Zone::Inner, 7, 30);
    Journey j2(Zone::Outer, 9, 0);
    Journey j3(Zone::Middle, 18, 15);

    cout << "Card " << card.getId() << " start balance: ";
    printRs(card.getBalance());
    cout << "\n\n";

    Journey trips[] = {j1, j2, j3};
    for (const Journey& j : trips) {
        long long f = j.computeFare(table, p1);
        cout << p1.getName() << " " << zoneName(j.getZone()) << " at "
             << j.getHour() << ":" << (j.getMinute() < 10 ? "0" : "") << j.getMinute()
             << (table.isPeak(j.getHour(), j.getMinute()) ? " (peak)" : " (off-peak)")
             << " fare ";
        printRs(f);
        if (card.deduct(f)) {
            cout << " -> allowed, balance ";
            printRs(card.getBalance());
        } else {
            cout << " -> DENIED, balance stays ";
            printRs(card.getBalance());
        }
        cout << "\n";
    }

    cout << "\nSame Outer peak journey for student " << p2.getName() << ": ";
    printRs(j2.computeFare(table, p2));
    cout << "\n";

    cout << "\nTrying recharge of -500 paise: " << (card.recharge(-500) ? "accepted" : "rejected") << "\n";
    cout << "Trying recharge of Rs 200: " << (card.recharge(20000) ? "accepted" : "rejected") << ", balance ";
    printRs(card.getBalance());
    cout << "\n";

    cout << "\nsizeof(SmartCard) = " << sizeof(SmartCard) << " bytes\n";
    return 0;
}
