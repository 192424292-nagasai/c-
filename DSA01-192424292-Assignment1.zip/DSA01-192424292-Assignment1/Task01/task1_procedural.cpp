// Task 1 - Alternative: same fare problem in purely procedural style
// (global variables + free functions, no classes)
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

// global data - anyone can change these
long long cardBalance = 10000;   // paise
int cardId = 101;

long long baseFare(int zone)     // 0 = Inner, 1 = Middle, 2 = Outer
{
    if (zone == 0) return 1000;
    if (zone == 1) return 2000;
    if (zone == 2) return 3000;
    return 0;
}

bool isPeak(int hour, int minute)
{
    int t = hour * 60 + minute;
    return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
}

long long fare(int zone, int hour, int minute)
{
    long long f = baseFare(zone);
    if (isPeak(hour, minute)) f = f + f * 20 / 100;
    return f;
}

void printRs(long long paise)
{
    cout << "Rs " << paise / 100 << "." << (paise % 100 < 10 ? "0" : "") << paise % 100;
}

int main()
{
    int zones[]   = {0, 2, 1};
    int hours[]   = {7, 9, 18};
    int minutes[] = {30, 0, 15};

    cout << "Card " << cardId << " start balance: ";
    printRs(cardBalance);
    cout << "\n";

    for (int i = 0; i < 3; i++) {
        long long f = fare(zones[i], hours[i], minutes[i]);
        cout << "Journey " << i + 1 << " fare ";
        printRs(f);
        if (cardBalance - f >= 5000) {      // rule written here by hand
            cardBalance -= f;
            cout << " allowed, balance ";
        } else {
            cout << " DENIED, balance ";
        }
        printRs(cardBalance);
        cout << "\n";
    }

    // Problem of procedural style: nothing stops this line
    cardBalance = cardBalance - 99999;
    cout << "\nAfter a wrong line in some other function, balance = ";
    cout << cardBalance << " paise  (negative! no class to protect it)\n";
    cout << "Memory for one card = sizeof(long long)+sizeof(int) = "
         << sizeof(cardBalance) + sizeof(cardId) << " bytes\n";
    return 0;
}
