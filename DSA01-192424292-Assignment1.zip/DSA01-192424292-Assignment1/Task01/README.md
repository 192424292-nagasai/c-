# Task 1 - Understand the Problem and Identify the Objects

## Files
| File | What it does |
|---|---|
| task1_objects.cpp | OOP version: Zone, FareTable, Passenger, SmartCard, Journey classes |
| task1_procedural.cpp | Alternative: same logic with global variables and free functions |
| output/ | program output |
| screenshots/ | output screenshots |

No input file is needed (journeys are written inside main).

## Objects, data and behaviour
| Object | Data | Behaviour | Why it is an object |
|---|---|---|---|
| Zone | Inner / Middle / Outer | - | fixed set of values, so enum class |
| FareTable | base fare of each zone, surcharge %, peak windows | baseFare(), isPeak(), fare() | all fare rules kept in one place, so a revision is done once |
| Passenger | name, type (Adult / Student / Senior) | concessionPercent() | concession depends on the person, not on the card |
| SmartCard | card id, balance (private, in paise) | recharge(), canTravel(), deduct() | balance must be protected so it never goes below Rs 50 |
| Journey | zone, hour, minute | computeFare() | one trip = one fare calculation |

## Procedural vs OOP
- Procedural: balance is a global variable, `fare()` and `isPeak()` are free functions, and every caller has to remember to check the Rs 50 rule. In the output the balance became -94599 paise after one wrong line.
- OOP: the balance is private inside SmartCard and only `deduct()` can change it, and `deduct()` checks the rule itself.

## OOP principles in this system
- Encapsulation: balance is private in SmartCard.
- Abstraction: the gate only calls `journey.computeFare()`, it does not need to know how peak is decided.
- Inheritance: a MonthlyPassCard or StudentCard could be derived from SmartCard later.
- Polymorphism: a virtual `concessionPercent()` could give different results for Student / Senior passengers.

## Rules every correct journey must satisfy
1. Balance after the journey is at least Rs 50 (5000 paise), otherwise the journey is denied and the balance is not changed.
2. Fare = base fare of the farthest zone, +20% only if 08:00 <= time < 10:00 or 17:00 <= time < 20:00.
3. All money is whole paise (long long), never double.
4. Recharge amount must be > 0.
5. Zone must be 0, 1 or 2 and time must be a real time (0-23 h, 0-59 min).

Assumptions: student concession 15%, senior 50% (not given in the question); the concession is applied after the peak surcharge; 10:00 and 20:00 are off-peak.

## Result
Rs 100 card: Rs 10 (off-peak Inner) and Rs 36 (peak Outer) were allowed, then the Rs 24 journey was denied because it would leave Rs 30. Negative recharge was rejected.

## Alternative concept and complexity
| | OOP classes | Procedural |
|---|---|---|
| Time per journey | O(1) | O(1) |
| Memory per card | O(1), 16 bytes (sizeof SmartCard) | O(1), 12 bytes (long long + int, without padding) |
| One fare rule changes | change one member function in FareTable | find every place the rule is written (fare(), main, other files) |
| Can balance go negative? | No - private + deduct() checks | Yes - shown in output (-94599 paise) |

Both are O(1); the difference is only in how safe and easy the code is to change.
