#!/bin/bash
# Compiles and runs every program of Assignment 1.
# Output of each program is saved as <program>_output.txt inside its Task folder,
# compiler messages are saved as <program>_compile.txt.
# Usage:  bash run_all.sh
FLAGS="-std=c++17 -Wall -Wextra"

run() {   # run <folder> <file.cpp> [input file] [program args]
    dir=$1; src=$2; in=$3; args=$4
    name=${src%.cpp}
    cd "$dir" || exit 1
    mkdir -p output
    echo "== $dir/$src"
    g++ $FLAGS "$src" -o "$name" > "output/${name}_compile.txt" 2>&1
    if [ $? -ne 0 ]; then
        echo "   compile FAILED (see output/${name}_compile.txt)"
        cd ..; return
    fi
    if [ -n "$in" ]; then
        ./"$name" $args < "$in" > "output/${name}_output.txt" 2>&1
    else
        ./"$name" $args > "output/${name}_output.txt" 2>&1
    fi
    echo "   exit code $?"
    cd ..
}

run Task01 task1_objects.cpp
run Task01 task1_procedural.cpp
run Task02 task2_constants.cpp
run Task02 task2_macro_version.cpp
run Task03 task3_datatypes.cpp
run Task04 task4_predict.cpp
run Task04 task4_fixed.cpp
run Task04 narrowing_error.cpp          # expected to FAIL compiling
run Task05 task5_predict.cpp
run Task05 task5_expressions.cpp
run Task06 task6_complete.cpp
run Task06 task6_peak_boundary.cpp input.txt
run Task06 task6_array_version.cpp
run Task07 task7_procedural.cpp
run Task07 task7_oop.cpp
run Task07 task7_public_balance.cpp
run Task08 task8_gate_io.cpp input.txt
run Task08 task8_getline_version.cpp input.txt
run Task09 task9_tests.cpp
run Task10 task10_totals.cpp
run Task10 warnings_demo.cpp
run Task11 task11_final.cpp "" fares.cfg
cd Task11 && ./task11_final fares_revised.cfg > output/task11_final_revised_output.txt && ./task11_final > output/task11_final_default_output.txt && cd ..
run Task12 task12_old_design_impact.cpp
run Task12 task12_redesign.cpp
