# Task 3 - Data Types and Type Compatibility

## Files
| File | What it does |
|---|---|
| task3_datatypes.cpp | sizeof, climits ranges, double vs paise precision, rounding error growth, mixed expressions |

No input file is needed.

## Data type table (sizes measured with sizeof on my system, g++ 13, 64-bit Linux)
| Value | Type chosen | sizeof | Range | Why |
|---|---|---|---|---|
| fare, balance, day total | long long (paise) | 8 | up to 9.22 x 10^18 | exact, no rounding, no overflow |
| hour, minute | int | 4 | up to 2,147,483,647 | small whole numbers |
| zone | enum class Zone | 4 | 3 values | type safe |
| journey count at one gate | unsigned / long long | 4 / 8 | 4,294,967,295 | count is never negative |
| peak? / blocked? | bool | 1 | true/false | yes/no value |
| passenger type code | char | 1 | 'A','S','C' | one letter |
| float / double | not used for money | 4 / 8 | 15 digits (double) | rounding errors |

## Why paise and not double rupees
- `0.1 + 0.2` printed `0.30000000000000004`, not equal to 0.3.
- `Rs 0.29 * 100` gave `28.999999999999996`; `(int)` cast gave **28 paise** - off by a paisa (the bug in the scenario). `llround` fixed it (29).
- Adding a Rs 10.20 student fare 3,000,000 times in double gave an error of about 1.5e-03 rupees; in paise it is exact.

## Is int enough?
Worst case network day = 3,000,000 x 3600 = 10,800,000,000 paise, which is more than INT_MAX (2,147,483,647). So **int is not enough**, long long is used (only 1.2e-07 % of LLONG_MAX).

## Type compatibility
- `int * double` -> the int is converted to double, result is double (24).
- `int + bool` -> bool becomes int (true = 1), result 21.
- `int / int` -> integer division, fraction lost (20/3 = 6).

## Alternative concept and complexity (double rupees vs long long paise)
Measured error when one Rs 10.20 fare is added n times:

| n | double total error (Rs) |
|---|---|
| 10 | 1.4e-14 |
| 1,000 | 4.0e-11 |
| 100,000 | -1.8e-06 |
| 1,000,000 | -2.4e-05 |
| 3,000,000 | -1.5e-03 |

| | double rupees | long long paise |
|---|---|---|
| Time per addition | O(1) | O(1) |
| Space per value | 8 bytes | 8 bytes |
| Error after n adds | grows roughly with n | always 0 |

Same time and space, but only paise is exact.
