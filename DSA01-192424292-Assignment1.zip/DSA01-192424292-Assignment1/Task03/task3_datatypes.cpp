// Task 3 - Data types, sizeof, ranges and type compatibility
// Name: J.Nagasai   Reg No: 192424292

#include <climits>
#include <cfloat>
#include <cmath>
#include <iomanip>
#include <iostream>
using namespace std;

int main()
{
    cout << "---- sizeof on this system ----\n";
    cout << "bool       " << sizeof(bool) << " byte  (card blocked? / peak?)\n";
    cout << "char       " << sizeof(char) << " byte  (passenger type code A/S/C)\n";
    cout << "int        " << sizeof(int) << " bytes (hour, minute, zone index)\n";
    cout << "unsigned   " << sizeof(unsigned) << " bytes (journey count per gate)\n";
    cout << "long long  " << sizeof(long long) << " bytes (fare, balance, day total in paise)\n";
    cout << "float      " << sizeof(float) << " bytes\n";
    cout << "double     " << sizeof(double) << " bytes\n";

    cout << "\n---- ranges from <climits> ----\n";
    cout << "INT_MAX    = " << INT_MAX << "\n";
    cout << "UINT_MAX   = " << UINT_MAX << "\n";
    cout << "LLONG_MAX  = " << LLONG_MAX << "\n";
    cout << "DBL_DIG    = " << DBL_DIG << " correct decimal digits in double\n";

    // is int enough for a network day? worst case every journey is Rs 36 peak outer
    long long worstNetwork = 3000000LL * 3600;   // paise
    cout << "\nWorst-case network day = " << worstNetwork << " paise";
    cout << (worstNetwork > INT_MAX ? "  > INT_MAX, so int is NOT enough\n" : "  fits in int\n");
    cout << "Same in long long uses only " << scientific << setprecision(3)
         << 100.0 * worstNetwork / LLONG_MAX << " % of LLONG_MAX\n";
    cout.unsetf(ios::floatfield);
    cout << setprecision(6);

    cout << "\n---- precision problem with double rupees ----\n";
    double a = 0.1, b = 0.2;
    cout << setprecision(17) << "0.1 + 0.2 = " << a + b << "  (== 0.3 ? "
         << (a + b == 0.3 ? "yes" : "no") << ")\n";

    double rupees = 0.29;
    int paiseWrong = static_cast<int>(rupees * 100);          // truncation
    long long paiseRight = llround(rupees * 100);             // rounding
    cout << "Rs 0.29 * 100 = " << rupees * 100 << "\n";
    cout << "int cast gives " << paiseWrong << " paise (off by a paisa!)\n";
    cout << "llround gives  " << paiseRight << " paise (correct)\n";

    cout << "\n---- rounding error growth: adding a Rs 10.20 student fare n times ----\n";
    cout << setprecision(10);
    cout << left << setw(12) << "n" << setw(22) << "double total (Rs)"
         << setw(22) << "paise total (Rs)" << "error (Rs)\n";
    long long counts[] = {10, 1000, 100000, 1000000, 3000000};
    for (long long n : counts) {
        double d = 0.0;
        long long p = 0;
        for (long long i = 0; i < n; i++) {
            d += 10.20;
            p += 1020;
        }
        double exact = p / 100.0;
        cout << setw(12) << n << setw(22) << fixed << setprecision(8) << d
             << setw(22) << setprecision(2) << exact
             << scientific << setprecision(3) << d - exact << "\n";
        cout.unsetf(ios::floatfield);
    }

    cout << "\n---- type compatibility in one expression ----\n";
    int fare = 20;
    double rate = 1.2;
    bool peak = true;
    auto r1 = fare * rate;      // int -> double
    auto r2 = fare + peak;      // bool -> int (true = 1)
    auto r3 = fare / 3;         // int / int = int
    cout << "int*double = " << r1 << " (double, size " << sizeof(r1) << ")\n";
    cout << "int+bool   = " << r2 << " (int, size " << sizeof(r2) << ")\n";
    cout << "int/int    = " << r3 << " (fraction lost)\n";
    return 0;
}
