// Task 7 - Object-oriented version: SmartCard keeps balance private
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

enum class Zone { Inner, Middle, Outer };

class FareTable {
public:
    static constexpr long long BASE[3] = {1000, 2000, 3000};
    static constexpr int PEAK_PERCENT = 20;
    static long long fare(Zone z, bool peak)
    {
        long long f = BASE[static_cast<int>(z)];
        if (peak) f += f * PEAK_PERCENT / 100;
        return f;
    }
};

class SmartCard {
private:
    long long balance;                         // paise - nobody outside can touch it
public:
    static constexpr long long MIN_BALANCE = 5000;   // change here only

    explicit SmartCard(long long start) : balance(start < 0 ? 0 : start) {}

    long long getBalance() const { return balance; }

    bool canTravel(long long f) const { return f >= 0 && balance - f >= MIN_BALANCE; }

    bool deduct(long long f)                   // checks the rule itself
    {
        if (!canTravel(f)) return false;
        balance -= f;
        return true;
    }

    bool recharge(long long amount)
    {
        if (amount <= 0) return false;
        balance += amount;
        return true;
    }
};

int main()
{
    SmartCard card1(10000);
    SmartCard card2(6000);
    long long f = FareTable::fare(Zone::Outer, true);   // 3600

    cout << "Card 1 deduct 3600: " << (card1.deduct(f) ? "OK" : "DENIED")
         << ", balance " << card1.getBalance() << " paise\n";

    // same mistake as procedural: two trips without checking first
    cout << "Card 2 trip 1: " << (card2.deduct(f) ? "OK" : "DENIED")
         << ", balance " << card2.getBalance() << " paise\n";
    cout << "Card 2 trip 2: " << (card2.deduct(f) ? "OK" : "DENIED")
         << ", balance " << card2.getBalance() << " paise\n";

    cout << "Negative fare -100: " << (card1.deduct(-100) ? "OK" : "DENIED") << "\n";
    cout << "Recharge -500: " << (card1.recharge(-500) ? "OK" : "REJECTED") << "\n";
    // card2.balance = -9999;   // compile error: 'balance' is private
    cout << "sizeof(SmartCard) = " << sizeof(SmartCard) << " bytes (same as one long long)\n";
    return 0;
}
