# Task 7 - From Procedural to Object-Oriented

## Files
| File | What it does |
|---|---|
| task7_procedural.cpp | separate balance variables + free functions fare(), canTravel(), deduct() |
| task7_oop.cpp | SmartCard class with private balance, deduct() and canTravel() |
| task7_public_balance.cpp | alternative: balance as a public member |

No input file is needed.

## Results
| Same mistake: 2 trips of Rs 36 on a Rs 60 card without checking | Result |
|---|---|
| Procedural | balance = **-1200 paise** (negative) |
| OOP | both trips **DENIED**, balance stays 6000 paise |
| Public member | another function did `balance -= 20000` -> **-10000 paise** |

## How the class prevents a negative balance
1. `balance` is private, so no outside code can assign it (`card2.balance = -9999;` does not compile).
2. `deduct()` calls `canTravel()` itself before subtracting, so a caller cannot forget the check.
3. `canTravel()` also rejects a negative fare, `recharge()` rejects amount <= 0, the constructor turns a negative opening balance into 0.

## Which is easier to change when the minimum balance changes?
- OOP: change `SmartCard::MIN_BALANCE` in one line. Every journey uses it through `canTravel()`.
- Procedural: the constant is in one place too, but the check `balance - f >= MIN_BALANCE` is repeated wherever a programmer writes it, and places that skip the check are not found by the compiler.
So the OOP version is easier and safer to change.

## Alternative concept and complexity: public balance
| | private + deduct() | public balance |
|---|---|---|
| Time | O(1) | O(1) |
| Space | 8 bytes | 8 bytes (measured, no change) |
| Rule that can be broken | none from outside | "balance never below Rs 50" (and even never negative) can be broken by any part of the program |
