// Task 7 - Procedural version: separate variables and free functions
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

const long long MIN_BALANCE = 5000;     // paise

long long baseFare(int zone)
{
    switch (zone) {
        case 0: return 1000;
        case 1: return 2000;
        case 2: return 3000;
        default: return -1;
    }
}

long long fare(int zone, bool peak)
{
    long long f = baseFare(zone);
    if (peak) f += f * 20 / 100;
    return f;
}

bool canTravel(long long balance, long long f) { return balance - f >= MIN_BALANCE; }

void deduct(long long& balance, long long f) { balance -= f; }   // trusts the caller

int main()
{
    long long balance1 = 10000;   // card 1
    long long balance2 = 6000;    // card 2

    long long f = fare(2, true);  // Rs 36
    if (canTravel(balance1, f)) deduct(balance1, f);
    cout << "Card 1 after Outer peak: " << balance1 << " paise\n";

    // caller forgets to check canTravel - nothing stops it
    deduct(balance2, f);
    deduct(balance2, f);
    cout << "Card 2 after 2 trips without check: " << balance2 << " paise  <-- NEGATIVE\n";
    return 0;
}
