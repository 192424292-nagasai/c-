// Task 7 - Alternative: balance as a PUBLIC data member
// Shows which rule can be broken by any part of the program
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

struct SmartCardPublic {
    long long balance;      // public - anyone can write it
    bool canTravel(long long f) const { return balance - f >= 5000; }
};

void someOtherModule(SmartCardPublic& c)
{
    c.balance -= 20000;     // bypasses canTravel completely
}

int main()
{
    SmartCardPublic c{10000};
    someOtherModule(c);
    cout << "Balance after other module: " << c.balance << " paise\n";
    cout << "Rule 'balance never below Rs 50' is broken: "
         << (c.balance < 5000 ? "YES" : "NO") << "\n";
    cout << "sizeof(SmartCardPublic) = " << sizeof(SmartCardPublic) << " bytes (no change)\n";
    return 0;
}
