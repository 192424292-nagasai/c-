# Task 9 - Implement and Test the Fare Logic

## Files
| File | What it does |
|---|---|
| metro_fare.h | complete fare logic: constants, isPeak(), computeFare(), SmartCard |
| task9_tests.cpp | table-driven tests + card tests + letters-for-hour test + 5-journey hand total |

The test inputs are inside the test table in task9_tests.cpp (no separate input file).

## Test table (expected vs actual, in paise)
| Test case | Expected | Actual | Result |
|---|---|---|---|
| Inner off-peak 11:00 adult | 1000 | 1000 | PASS |
| Middle off-peak 14:30 adult | 2000 | 2000 | PASS |
| Outer off-peak 22:00 adult | 3000 | 3000 | PASS |
| Inner peak 08:30 adult | 1200 | 1200 | PASS |
| Middle peak 18:00 adult | 2400 | 2400 | PASS |
| Outer peak 09:00 adult | 3600 | 3600 | PASS |
| Outer peak 09:00 student | 3060 | 3060 | PASS |
| Middle off-peak 12:00 senior | 1000 | 1000 | PASS |
| Inner peak 19:00 senior | 600 | 600 | PASS |
| Boundary 07:59 | 2000 | 2000 | PASS |
| Boundary 08:00 | 2400 | 2400 | PASS |
| Boundary 09:59 | 2400 | 2400 | PASS |
| Boundary 10:00 | 2000 | 2000 | PASS |
| Boundary 16:59 | 3000 | 3000 | PASS |
| Boundary 17:00 | 3600 | 3600 | PASS |
| Boundary 19:59 | 3600 | 3600 | PASS |
| Boundary 20:00 | 3000 | 3000 | PASS |
| Invalid zone 3 / -1 | -1 | -1 | PASS |
| Invalid hour 24 / minute 60 | -1 | -1 | PASS |
| Rs 70 card, Rs 20 fare -> leaves exactly Rs 50 | allowed, 5000 | allowed, 5000 | PASS |
| Next Rs 10 fare (would leave Rs 40) | denied | denied | PASS |
| Negative recharge -1000 / zero recharge | rejected | rejected | PASS |
| Letters "ab" typed for hour | fail() set, recovered | fail() set, recovered | PASS |
| 5-journey total | 9340 | 9340 | PASS |

**35 passed, 0 failed.**

## 5 journeys calculated by hand
| # | Journey | Working | Fare |
|---|---|---|---|
| 1 | Inner 11:00 adult | 1000 | Rs 10.00 |
| 2 | Outer 08:15 adult | 3000 + 600 | Rs 36.00 |
| 3 | Middle 17:45 student | 2400 - 360 | Rs 20.40 |
| 4 | Outer 13:00 senior | 3000 - 1500 | Rs 15.00 |
| 5 | Inner 09:59 adult | 1000 + 200 | Rs 12.00 |
| | **Total** | | **Rs 93.40** |

Card Rs 200 -> Rs 106.60 after the 5 journeys (program also gave 10660 paise).

## Alternative concept and complexity: table of test cases
| | separate hand-written checks | table + loop |
|---|---|---|
| Time for t tests | O(t) | O(t) |
| Space | no table | O(t), one row per test |
| Adding a new boundary case | copy a block of code | add one line to the table |

I used the table (Part A) because adding a case like "Boundary 19:59" was only one line.
