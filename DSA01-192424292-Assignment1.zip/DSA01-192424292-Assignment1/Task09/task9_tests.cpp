// Task 9 - Implement and test the fare logic
// Part A: table-driven tests (inputs + expected fare in a loop)
// Part B: card / balance tests
// Part C: invalid input (letters for hour) using a stringstream
// Part D: 5 journeys whose total is calculated by hand
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>
#include <sstream>
#include "metro_fare.h"
using namespace std;

int passed = 0, failed = 0;

void check(const string& name, long long expected, long long actual)
{
    bool ok = expected == actual;
    ok ? passed++ : failed++;
    cout << left << setw(42) << name << right << setw(9) << expected << setw(9) << actual
         << "   " << (ok ? "PASS" : "FAIL") << "\n";
}

int main()
{
    struct TestCase { string name; int zone; int h; int m; PassengerType p; long long expected; };
    using P = PassengerType;
    TestCase tests[] = {
        // normal journeys, each zone, peak and off-peak
        {"Inner off-peak 11:00 adult",      0, 11,  0, P::Adult,   1000},
        {"Middle off-peak 14:30 adult",     1, 14, 30, P::Adult,   2000},
        {"Outer off-peak 22:00 adult",      2, 22,  0, P::Adult,   3000},
        {"Inner peak 08:30 adult",          0,  8, 30, P::Adult,   1200},
        {"Middle peak 18:00 adult",         1, 18,  0, P::Adult,   2400},
        {"Outer peak 09:00 adult",          2,  9,  0, P::Adult,   3600},
        {"Outer peak 09:00 student",        2,  9,  0, P::Student, 3060},
        {"Middle off-peak 12:00 senior",    1, 12,  0, P::Senior,  1000},
        {"Inner peak 19:00 senior",         0, 19,  0, P::Senior,   600},
        // boundary cases
        {"Boundary 07:59 Middle (off-peak)",1,  7, 59, P::Adult,   2000},
        {"Boundary 08:00 Middle (peak)",    1,  8,  0, P::Adult,   2400},
        {"Boundary 09:59 Middle (peak)",    1,  9, 59, P::Adult,   2400},
        {"Boundary 10:00 Middle (off-peak)",1, 10,  0, P::Adult,   2000},
        {"Boundary 16:59 Outer (off-peak)", 2, 16, 59, P::Adult,   3000},
        {"Boundary 17:00 Outer (peak)",     2, 17,  0, P::Adult,   3600},
        {"Boundary 19:59 Outer (peak)",     2, 19, 59, P::Adult,   3600},
        {"Boundary 20:00 Outer (off-peak)", 2, 20,  0, P::Adult,   3000},
        // invalid
        {"Invalid zone 3",                  3, 10,  0, P::Adult,     -1},
        {"Invalid zone -1",                -1, 10,  0, P::Adult,     -1},
        {"Invalid hour 24",                 0, 24,  0, P::Adult,     -1},
        {"Invalid minute 60",               0,  9, 60, P::Adult,     -1},
    };

    cout << "PART A - fare table tests\n";
    cout << left << setw(42) << "Test case" << right << setw(9) << "Expected" << setw(9) << "Actual" << "   Result\n";
    cout << string(70, '-') << "\n";
    for (const TestCase& t : tests)
        check(t.name, t.expected, computeFare(t.zone, t.h, t.m, t.p));

    cout << "\nPART B - card and balance tests\n";
    cout << string(70, '-') << "\n";
    SmartCard c1(7000);                         // Rs 70
    check("Rs 70 card, Rs 20 fare -> leaves exactly Rs 50", 1, c1.deduct(2000));
    check("  balance after that (paise)", 5000, c1.getBalance());
    check("Next Rs 10 fare denied (would be Rs 40)", 0, c1.deduct(1000));
    check("  balance unchanged", 5000, c1.getBalance());
    check("Negative recharge -1000 rejected", 0, c1.recharge(-1000));
    check("Zero recharge rejected", 0, c1.recharge(0));
    check("Recharge Rs 100 accepted", 1, c1.recharge(10000));
    check("  balance after recharge", 15000, c1.getBalance());
    check("Invalid fare -1 cannot be deducted", 0, c1.deduct(-1));
    SmartCard c2(-500);
    check("Card created with negative balance -> 0", 0, c2.getBalance());

    cout << "\nPART C - letters typed for the hour\n";
    cout << string(70, '-') << "\n";
    istringstream in("2 ab 30");
    int zone = -1, hour = -1, minute = -1;
    in >> zone >> hour;
    bool failedRead = in.fail();
    check("Reading 'ab' as hour sets fail()", 1, failedRead);
    in.clear();
    string junk;
    in >> junk >> minute;
    check("After clear(), junk skipped, minute read", 30, minute);

    cout << "\nPART D - 5 journeys, total calculated by hand\n";
    cout << string(70, '-') << "\n";
    // by hand: 1000 + 3600 + 2040 + 1500 + 1200 = 9340 paise = Rs 93.40
    long long f1 = computeFare(0, 11, 0, P::Adult);     // Rs 10.00
    long long f2 = computeFare(2, 8, 15, P::Adult);     // Rs 36.00
    long long f3 = computeFare(1, 17, 45, P::Student);  // 2400 - 15% = Rs 20.40
    long long f4 = computeFare(2, 13, 0, P::Senior);    // 3000 - 50% = Rs 15.00
    long long f5 = computeFare(0, 9, 59, P::Adult);     // Rs 12.00
    SmartCard day(20000);
    long long fares[] = {f1, f2, f3, f4, f5};
    long long total = 0;
    for (long long f : fares) {
        if (day.deduct(f)) total += f;
    }
    check("Total of 5 journeys (paise)", 9340, total);
    check("Card balance after (20000 - 9340)", 10660, day.getBalance());

    cout << "\n" << passed << " passed, " << failed << " failed\n";
    return failed == 0 ? 0 : 1;
}
