// Task 9 - Complete fare logic (header used by the test program)
// Name: J.Nagasai   Reg No: 192424292
#ifndef METRO_FARE_H
#define METRO_FARE_H

#include <string>

enum class Zone { Inner, Middle, Outer };
enum class PassengerType { Adult, Student, Senior };

// ---------- one place for every rule ----------
constexpr long long BASE_FARE_PAISE[] = {1000, 2000, 3000};
constexpr int  ZONE_COUNT = 3;
constexpr int  PEAK_SURCHARGE_PERCENT = 20;
constexpr int  STUDENT_CONCESSION_PERCENT = 15;   // assumption
constexpr int  SENIOR_CONCESSION_PERCENT = 50;    // assumption
constexpr long long MIN_BALANCE_PAISE = 5000;
// ----------------------------------------------

inline bool isValidZone(int z) { return z >= 0 && z < ZONE_COUNT; }

inline bool isValidTime(int h, int m) { return h >= 0 && h <= 23 && m >= 0 && m <= 59; }

inline bool isPeak(int hour, int minute)
{
    int t = hour * 60 + minute;
    return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
}

inline int concessionPercent(PassengerType p)
{
    switch (p) {
        case PassengerType::Student: return STUDENT_CONCESSION_PERCENT;
        case PassengerType::Senior:  return SENIOR_CONCESSION_PERCENT;
        default:                     return 0;
    }
}

// returns fare in paise, or -1 if the data is invalid
inline long long computeFare(int zone, int hour, int minute, PassengerType p)
{
    if (!isValidZone(zone) || !isValidTime(hour, minute)) return -1;
    long long f = BASE_FARE_PAISE[zone];
    if (isPeak(hour, minute)) f += f * PEAK_SURCHARGE_PERCENT / 100;
    f -= f * concessionPercent(p) / 100;
    return f;
}

class SmartCard {
    long long balance;
public:
    explicit SmartCard(long long b) : balance(b < 0 ? 0 : b) {}
    long long getBalance() const { return balance; }
    bool canTravel(long long f) const { return f >= 0 && balance - f >= MIN_BALANCE_PAISE; }
    bool deduct(long long f)
    {
        if (!canTravel(f)) return false;
        balance -= f;
        return true;
    }
    bool recharge(long long amount)
    {
        if (amount <= 0) return false;
        balance += amount;
        return true;
    }
};

#endif
