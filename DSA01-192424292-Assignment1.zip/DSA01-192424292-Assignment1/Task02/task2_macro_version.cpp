// Task 2 - Alternative: same constants written with #define macros
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

#define INNER_FARE 1000
#define MIDDLE_FARE 2000
#define OUTER_FARE 3000
#define PEAK_SURCHARGE 20
#define MIN_BALANCE 5000
#define PEAK_FARE(b) b + b * PEAK_SURCHARGE / 100     // no brackets - classic macro bug

int main()
{
    // macro is just text replacement, no type, no scope
    cout << "Outer fare = " << OUTER_FARE << "\n";

    // Bug 1: PEAK_FARE(OUTER_FARE) * 2 expands to 3000 + 3000*20/100 * 2
    cout << "Two outer peak fares (expected 7200): " << PEAK_FARE(OUTER_FARE) * 2 << "\n";

    // Bug 2: passing an expression
    cout << "Peak fare of (1000+2000) expected 3600: " << PEAK_FARE(INNER_FARE + MIDDLE_FARE) << "\n";

    // Bug 3: macro has no type - this compiles even though a fare is not a char
    char c = OUTER_FARE / 100;   // 30 -> stored as char 30 (control character)
    cout << "Fare stored in char (as int) = " << static_cast<int>(c) << "\n";

#undef MIN_BALANCE
#define MIN_BALANCE 50      // someone redefines it in rupees by mistake - no error
    cout << "MIN_BALANCE after redefine = " << MIN_BALANCE << " (unit changed silently)\n";
    return 0;
}
