# Task 2 - Tokens, Keywords, Identifiers and Constants

## Files
| File | What it does |
|---|---|
| task2_constants.cpp | all fares and limits defined once with constexpr + enum class, static_assert check |
| task2_macro_version.cpp | alternative using #define macros, shows macro bugs |
| output/task2_constants_compile.txt | -Wenum-compare warning for the old enum comparison |

No input file is needed.

## The five kinds of tokens (examples from my program)
| Token | Examples |
|---|---|
| Keywords | `constexpr`, `enum`, `class`, `int`, `long`, `return`, `const`, `for` |
| Identifiers | `BASE_FARE_PAISE`, `PEAK_SURCHARGE_PERCENT`, `peakFare`, `Zone`, `idx` |
| Constants (literals) | `1000`, `20`, `5000`, `'0'`, `"Rs "` |
| Operators | `=`, `+`, `*`, `/`, `<<`, `::`, `==`, `>=` |
| Punctuators | `;`, `{ }`, `( )`, `[ ]`, `,` |

## #define vs const vs constexpr
| | #define | const | constexpr |
|---|---|---|---|
| Has a type | no (text replace) | yes | yes |
| Has scope | no | yes | yes |
| Known at compile time | yes | only sometimes | always |
| Can be used in static_assert / array size | yes but no type check | not always | yes |

constexpr is preferred for the fare table because it has a type, it is checked by the compiler (my `static_assert(peakFare(BASE_FARE_PAISE[2]) == 3600)` fails the build if someone types a wrong fare), and it costs nothing at run time.

## enum vs enum class
- Old `enum OldZone { INNER, MIDDLE, OUTER }`: `OUTER + 10` compiled and gave 12, and `GREEN == MIDDLE` (two unrelated enums) compiled with only a warning.
- `enum class Zone`: `Zone::Middle == 1` and `int x = Zone::Outer` do not compile. We must write `static_cast<int>(z)`. Names are also scoped (`Zone::Inner`), so they cannot clash.

## Identifier naming rules and conventions
- Rules: letters, digits, `_`; cannot start with a digit; cannot be a keyword; case sensitive.
- Conventions I used: `UPPER_CASE` for constants, `camelCase` for functions/variables, `PascalCase` for classes/enums, unit in the name (`_PAISE`, `_PERCENT`).

## Result
Fare table printed from one constexpr array (10/12, 20/24, 30/36). Macro version gave wrong answers: 4200 instead of 7200 and 4400 instead of 3600, because the macro has no brackets.

## Alternative concept and complexity
| | #define macros | constexpr + enum class |
|---|---|---|
| Type checking | none, `char c = OUTER_FARE/100` compiled | full type checking |
| Scope | whole file after the #define, can be redefined silently (MIN_BALANCE 5000 -> 50) | normal C++ scope |
| Memory | 0 bytes (text replacement) | usually 0 bytes too (compiler puts the value directly in the code); the array is 24 bytes if indexed at run time |
| Running time | O(1), same | O(1), same |

So running time and memory are the same; constexpr is safer.
