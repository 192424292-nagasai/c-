// Task 2 - Tokens, keywords, identifiers and constants
// All fares and limits are defined in ONE place below.
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
using namespace std;

// ---------- single place for every fare rule ----------
enum class Zone { Inner, Middle, Outer };          // enum class = scoped + type safe

constexpr long long BASE_FARE_PAISE[] = {1000, 2000, 3000};   // Rs 10, 20, 30
constexpr int  PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;      // Rs 50
constexpr int  MORNING_PEAK_START = 8 * 60;        // 8:00 in minutes
constexpr int  MORNING_PEAK_END   = 10 * 60;       // 10:00 (not included)
constexpr int  EVENING_PEAK_START = 17 * 60;       // 17:00
constexpr int  EVENING_PEAK_END   = 20 * 60;       // 20:00 (not included)
// --------------------------------------------------------

// constexpr function - can even be calculated at compile time
constexpr long long peakFare(long long base)
{
    return base + base * PEAK_SURCHARGE_PERCENT / 100;
}

// checked by the compiler, program will not compile if the table is wrong
static_assert(peakFare(BASE_FARE_PAISE[2]) == 3600, "Outer peak fare must be Rs 36");

// old style enum - for comparison only
enum OldZone { INNER, MIDDLE, OUTER };

int main()
{
    // tokens in this line:  keyword(const) keyword(int) identifier(n) operator(=) constant(3) punctuator(;)
    const int n = 3;

    cout << "Fare table (from the single constexpr table)\n";
    for (int i = 0; i < n; i++) {
        cout << "Zone " << i << " : base " << BASE_FARE_PAISE[i] / 100
             << "  peak " << peakFare(BASE_FARE_PAISE[i]) / 100 << "\n";
    }

    Zone z = Zone::Outer;
    // int bad = z;            // ERROR: enum class does not convert to int by itself
    int idx = static_cast<int>(z);   // must be explicit
    cout << "\nZone::Outer as index = " << idx << "\n";

    OldZone oz = OUTER;
    int sum = oz + 10;         // old enum silently becomes int (unsafe)
    cout << "Old enum OUTER + 10 = " << sum << "  (compiles silently - unsafe)\n";

    // comparing two old enums of different meaning also compiles - another danger
    enum Colour { RED, GREEN, BLUE };
    if (GREEN == MIDDLE)
        cout << "GREEN == MIDDLE is true for old enum (meaningless comparison compiled)\n";
    // if (Zone::Middle == 1) {} // enum class: compile error, so this mistake is caught

    cout << "\nMinimum balance = Rs " << MIN_BALANCE_PAISE / 100 << "\n";
    cout << "Peak windows (minutes) = " << MORNING_PEAK_START << "-" << MORNING_PEAK_END
         << " and " << EVENING_PEAK_START << "-" << EVENING_PEAK_END << "\n";
    cout << "sizeof(Zone) = " << sizeof(Zone) << ", sizeof(BASE_FARE_PAISE) = "
         << sizeof(BASE_FARE_PAISE) << " bytes\n";
    return 0;
}
