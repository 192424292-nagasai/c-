# DSA01-192424292-Assignment1

**Assignment 1 (CO1) - Design, Implement and Validate the Fare Logic of a City Metro Smart-Card System**

| | |
|---|---|
| Name | J.Nagasai |
| Register Number | 192424292 |
| Compiler | g++ (Ubuntu 13.3.0) 13.3.0 |
| Compile command | `g++ -std=c++17 -Wall -Wextra file.cpp -o file` |
| OS | Linux 64-bit |

## Folder structure
Each task has its own folder:
```
TaskXX/
   *.cpp            source code
   input.txt        input file (only where the program reads input)
   output/          program output (*_output.txt) and compiler messages (*_compile.txt)
   screenshots/     screenshot of compile + run
   README.md        discussion, results and complexity analysis of that task
```

## How to compile and run
Run everything at once:
```
bash run_all.sh
```
Or one program at a time, for example:
```
cd Task06
g++ -std=c++17 -Wall -Wextra task6_complete.cpp -o task6_complete
./task6_complete
g++ -std=c++17 -Wall -Wextra task6_peak_boundary.cpp -o task6_peak_boundary
./task6_peak_boundary < input.txt
```
Programs that read input: `Task06/task6_peak_boundary` and `Task08/*` (use `< input.txt`), `Task11/task11_final` (give `fares.cfg` as argument).

`Task04/narrowing_error.cpp` is **supposed to fail** compiling - it proves brace initialisation stops narrowing.

## Short result of each task
| Task | Programs | Result |
|---|---|---|
| 1 Objects | task1_objects, task1_procedural | 5 objects identified; OOP card denied a Rs 24 trip that would leave Rs 30; procedural balance went to -94599 paise |
| 2 Constants | task2_constants, task2_macro_version | one constexpr fare table with static_assert; macros gave 4200 instead of 7200 |
| 3 Data types | task3_datatypes | int is not enough for a network day (1.08 x 10^10 paise); Rs 0.29 -> 28 paise with a cast (off by a paisa), fixed with llround |
| 4 Conversions | task4_predict, task4_fixed, narrowing_error | output `3 3.5 / C 68 / 1 true / s >= u`; -Wsign-compare warning; `int x{3.7}` gives a compile error |
| 5 Precedence | task5_predict, task5_expressions | output `11 16 / 9 6 4 / 6 4 / 3 1 -3 -1 / 18`; missing brackets with ?: gave 600 instead of 3600 |
| 6 Control structures | task6_complete, task6_peak_boundary, task6_array_version | output matches the expected output exactly; 10:00 and 20:00 are off-peak |
| 7 Procedural vs OOP | task7_procedural, task7_oop, task7_public_balance | procedural -1200 paise, OOP denied both trips, public member -10000 paise |
| 8 Input/Output | task8_gate_io, task8_getline_version | 5 bad lines (letters, zone 3, minute 61, type Z) skipped, 6 journeys in report, total Rs 137.00 |
| 9 Testing | task9_tests | 35 tests, 35 passed (normal, boundary, invalid, 5-journey hand total Rs 93.40) |
| 10 Expectation vs execution | task10_totals, warnings_demo | int overflows at journey 1,132,640; double off by 3.9e-05 Rs at 3 million; long long exact |
| 11 Final design | task11_final | fares read from fares.cfg; revision done by editing the file, no recompile |
| 12 Design challenge | task12_old_design_impact, task12_redesign | old switch gave Airport fare 0; modified design (fare table + TimeRule + MonthlyPass) - 17 tests passed |

## Assumptions
- Student concession 15%, senior citizen concession 50% (percentages not given in the question).
- Peak = 08:00 to 09:59 and 17:00 to 19:59 (10:00 and 20:00 are off-peak).
- Concession is applied after the peak surcharge / weekend discount.
- All money is stored as whole paise in `long long`.
- Timing numbers (ms, ns) change a little every run; the values in the task READMEs are from the run saved in each output/ folder.
