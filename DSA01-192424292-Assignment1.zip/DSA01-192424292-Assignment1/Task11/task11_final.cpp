// Task 11 - Recommended final design
//  * money in long long paise, constants in one FareConfig object
//  * defaults compiled in (constexpr), optional fares.cfg read at start-up
//  * SmartCard keeps balance private
// Run: ./task11_final fares.cfg   (or without argument to use built-in defaults)
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

enum class PassengerType { Adult, Student, Senior };

class FareConfig {
public:
    vector<long long> baseFare{1000, 2000, 3000};   // compiled defaults
    int peakPercent = 20;
    int studentPercent = 15;
    int seniorPercent = 50;
    long long minBalance = 5000;

    bool loadFromFile(const string& path)
    {
        ifstream f(path);
        if (!f) return false;
        string key;
        while (f >> key) {
            if (key[0] == '#') { getline(f, key); continue; }
            if (key == "ZONES") { int z; f >> z; baseFare.assign(z, 0); }
            else if (key == "FARE") { int i; long long v; f >> i >> v;
                if (i >= 0 && i < (int)baseFare.size()) baseFare[i] = v; }
            else if (key == "PEAK_SURCHARGE_PERCENT") f >> peakPercent;
            else if (key == "STUDENT_CONCESSION_PERCENT") f >> studentPercent;
            else if (key == "SENIOR_CONCESSION_PERCENT") f >> seniorPercent;
            else if (key == "MIN_BALANCE") f >> minBalance;
            else getline(f, key);   // unknown key - ignore rest of line
        }
        return true;
    }

    bool isPeak(int h, int m) const
    {
        int t = h * 60 + m;
        return (t >= 8 * 60 && t < 10 * 60) || (t >= 17 * 60 && t < 20 * 60);
    }

    long long fare(int zone, int h, int m, PassengerType p) const
    {
        if (zone < 0 || zone >= (int)baseFare.size()) return -1;
        if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
        long long f = baseFare[zone];
        if (isPeak(h, m)) f += f * peakPercent / 100;
        if (p == PassengerType::Student) f -= f * studentPercent / 100;
        if (p == PassengerType::Senior)  f -= f * seniorPercent / 100;
        return f;
    }
};

class SmartCard {
    long long balance;
    const FareConfig& cfg;
public:
    SmartCard(long long b, const FareConfig& c) : balance(b < 0 ? 0 : b), cfg(c) {}
    long long getBalance() const { return balance; }
    bool canTravel(long long f) const { return f >= 0 && balance - f >= cfg.minBalance; }
    bool deduct(long long f) { if (!canTravel(f)) return false; balance -= f; return true; }
};

string rs(long long p)
{
    string s = to_string(p / 100) + ".";
    if (p % 100 < 10) s += "0";
    return s + to_string(p % 100);
}

int main(int argc, char* argv[])
{
    FareConfig cfg;
    auto t1 = chrono::high_resolution_clock::now();
    bool loaded = (argc > 1) && cfg.loadFromFile(argv[1]);
    auto t2 = chrono::high_resolution_clock::now();

    cout << "Fare table source: " << (loaded ? string("file ") + argv[1] : "built-in defaults") << "\n";
    cout << "Start-up read time: " << fixed << setprecision(1)
         << chrono::duration<double, micro>(t2 - t1).count() << " microseconds for "
         << cfg.baseFare.size() << " fare values\n";
    cout << "Memory for fare values: " << cfg.baseFare.size() * sizeof(long long) << " bytes\n\n";

    for (size_t z = 0; z < cfg.baseFare.size(); z++)
        cout << "Zone " << z << "  off-peak Rs " << rs(cfg.fare(z, 12, 0, PassengerType::Adult))
             << "  peak Rs " << rs(cfg.fare(z, 9, 0, PassengerType::Adult)) << "\n";

    SmartCard card(10000, cfg);
    struct J { int zone, h, m; PassengerType p; };
    J day[] = {{0, 11, 0, PassengerType::Adult}, {2, 9, 0, PassengerType::Adult},
               {1, 18, 0, PassengerType::Student}, {1, 20, 0, PassengerType::Senior}};
    cout << "\nDemo card Rs 100:\n";
    for (const J& j : day) {
        long long f = cfg.fare(j.zone, j.h, j.m, j.p);
        bool ok = card.deduct(f);
        cout << "  zone " << j.zone << " " << setw(2) << setfill('0') << j.h << ":" << setw(2) << j.m
             << setfill(' ') << " fare Rs " << rs(f) << (ok ? "  OK " : "  DENIED") << "  balance Rs "
             << rs(card.getBalance()) << "\n";
    }

    // network total check with long long
    long long total = 0;
    for (long long i = 0; i < 3000000; i++)
        total += cfg.fare(i % 3, (i % 4 == 0) ? 9 : 12, 0, PassengerType::Adult);
    cout << "\n3,000,000 adult journeys total = " << total << " paise = Rs " << rs(total) << "\n";
    return 0;
}
