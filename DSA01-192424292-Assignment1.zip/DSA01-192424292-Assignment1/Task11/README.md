# Task 11 - Recommend and Defend the Final Design

## Files
| File | What it does |
|---|---|
| task11_final.cpp | recommended design: FareConfig (defaults compiled in, optional config file) + SmartCard |
| fares.cfg | current fare table (Rs 10 / 20 / 30) |
| fares_revised.cfg | example revision (Rs 12 / 22 / 33) |

Run:
```
./task11_final fares.cfg          # read fares from file
./task11_final fares_revised.cfg  # fare revision, no recompile
./task11_final                    # built-in defaults
```

## Recommendation
| Item | Choice | Evidence |
|---|---|---|
| Money | long long paise | Task 3: double was off by a paisa (0.29 -> 28); Task 10: int overflowed at 1.13 million journeys |
| Constants | one place (constexpr defaults / FareConfig) | Task 2: macros gave 4200 instead of 7200 |
| Zone | enum class / index into a fare table | Task 2 and Task 6 |
| Peak check | minutes, `[08:00, 10:00)` and `[17:00, 20:00)` | Task 6/9 boundary tests at 8:00, 10:00, 17:00, 20:00 all passed |
| Balance | private in SmartCard, deduct() checks Rs 50 rule | Task 7: procedural reached -1200 paise, OOP denied |
| Input | cin.fail() + clear() + ignore() | Task 8: 5 bad lines skipped, no crash |

## How a fare revision is carried out
1. Edit `fares.cfg` (for example FARE 0 1200).
2. Restart the gate program - it reads the file at start-up.
3. Run the Task 9 tests with the new expected values.
No recompiling. If the file is missing, the program uses the compiled default values (shown in task11_final_default_output.txt).

## Limitations
- The config file is trusted; a bad value (like a negative fare) is not fully validated yet.
- Peak windows are still constants in code.
- Percentages use integer division, so a fare that is not a multiple of the percent can lose up to 1 paisa (all current fares are exact).
- No weekend / pass rules (handled in Task 12).

## Correct for the whole network?
Yes. 3,000,000 adult journeys total = 6,300,000,000 paise, which is more than INT_MAX but tiny for long long. Each journey is O(1), so 3 million journeys are O(n) and fast.

## Alternative concept and complexity: config file vs compiled-in table
| | compiled in | read from file at start |
|---|---|---|
| Start-up time | 0 | O(z) for z fares - measured about 153 microseconds for 3 values (includes opening the file) |
| Space | z x 8 bytes | z x 8 bytes (24 bytes here) + small file |
| Fare revision | edit code, recompile, redeploy to every gate | edit file, restart |
| Time per journey | O(1) | O(1) |
