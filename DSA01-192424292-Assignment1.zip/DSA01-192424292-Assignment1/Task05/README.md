# Task 5 - Expressions and Operator Precedence

## Files
| File | What it does |
|---|---|
| task5_predict.cpp | the given Predict-the-Output program (not changed) |
| task5_expressions.cpp | peak check (with and without brackets), lookup table bool peak[24], surcharge / concession, ++x vs x++, timing |
| output/task5_expressions_compile.txt | -Wparentheses warning for the no-bracket version |

No input file is needed.

## Expressions used
```cpp
bool peak = (t >= 8*60 && t < 10*60) || (t >= 17*60 && t < 20*60);   // t = minutes
long long fare = base + (peak ? base * PEAK_SURCHARGE_PERCENT / 100 : 0);
fare -= fare * concession / 100;
```
- `*` and `/` are done before `+`, left to right (`base * 20 / 100` = (base*20)/100, so no fraction is lost early).
- `?:` has very low precedence, so it needs brackets. Without them `base + peak ? ... : 0` became `(base + peak) ? ... : 0` and gave **600 instead of 3600** (shown in output).
- `-=` is evaluated last; the right side `fare * concession / 100` is fully computed first.

## My predicted output (written before running)
```
11 16
9 6 4
6 4
3 1 -3 -1
18
```
## Actual output
```
11 16
9 6 4
6 4
3 1 -3 -1
18
```
No difference.

## Line by line
| Line | Operators and order |
|---|---|
| `11 16` | `x + y * 2`: `*` first (6), then `+` = 11. `(x + y) * 2`: brackets first = 8 * 2 = 16. |
| `9 6 4` | `x++` gives old value 5 then x becomes 6; `++y` makes y 4 and gives 4. z = 5 + 4 = 9. |
| `6 4` | `x > y ? x : y` = 6 > 4 so 6. `x % 4 * 2`: `%` and `*` same level, left to right: (6 % 4) * 2 = 2 * 2 = 4. |
| `3 1 -3 -1` | integer division truncates toward zero: 10/3 = 3, 10%3 = 1, -10/3 = -3, -10%3 = -1 (sign of % follows the left operand). |
| `18` | i = 0, 3, 6, 9 (i += 3), k = 0+3+6+9 = 18. |

## x++ vs ++x and i = i++
`x++` returns the old value, `++x` returns the new value. `i = i++` changes i twice in one statement; before C++17 it was undefined behaviour, and even in C++17 it does nothing useful (i stays the same), so it is a mistake.

## With and without brackets
`hour >= 8 && hour < 10 || hour >= 17 && hour < 20` gives the same result because `&&` binds tighter than `||` (all 24 hours checked - YES). But g++ warns "suggest parentheses around '&&' within '||'" and a reader can easily misread it, so the bracket version is used.

Note: hour 10 and hour 20 are off-peak (`< 10`, `< 20`), 8 and 17 are peak.

## Alternative concept and complexity: bool peak[24] table
| | && / \|\| expression | lookup table |
|---|---|---|
| Time per check | O(1), up to 4 comparisons | O(1), 1 array read |
| Measured, 100 million checks | 411.5 ms | 308.4 ms |
| Extra space | 0 | 24 bytes |
| Minute precision (e.g. 9:59) | yes, using minutes | no, only whole hours (would need 1440 entries) |

The table was a bit faster on my machine, but it only works for whole hours, so I kept the expression with minutes.
