// Task 5 - Expressions for peak check, surcharge and concession
// + alternative: bool peak[24] lookup table, with time measurement
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <iostream>
using namespace std;

constexpr int PEAK_SURCHARGE_PERCENT = 20;

// readable version with brackets
bool isPeakExpr(int hour)
{
    return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
}

// same without brackets: && is done before ||, so result is same, but hard to read
bool isPeakNoBrackets(int hour)
{
    return hour >= 8 && hour < 10 || hour >= 17 && hour < 20;   // -Wall warns: suggest parentheses
}

// alternative: lookup table, 24 bytes
constexpr bool PEAK_TABLE[24] = {
    0,0,0,0,0,0,0,0,  // 0-7
    1,1,              // 8,9
    0,0,0,0,0,0,0,    // 10-16
    1,1,1,            // 17,18,19
    0,0,0,0           // 20-23
};
bool isPeakTable(int hour) { return PEAK_TABLE[hour]; }

int main()
{
    cout << "hour expr noBrackets table\n";
    bool allSame = true;
    for (int h = 0; h < 24; h++) {
        bool a = isPeakExpr(h), b = isPeakNoBrackets(h), c = isPeakTable(h);
        if (a != b || a != c) allSame = false;
        if (h == 7 || h == 8 || h == 9 || h == 10 || h == 16 || h == 17 || h == 19 || h == 20)
            cout << (h < 10 ? " " : "") << h << "    " << a << "    " << b << "          " << c << "\n";
    }
    cout << "All 24 hours give the same answer in all 3 methods: " << (allSame ? "YES" : "NO") << "\n\n";

    // surcharge and concession expressions (integer paise)
    long long base = 3000;
    bool peak = isPeakExpr(9);
    long long fare = base + (peak ? base * PEAK_SURCHARGE_PERCENT / 100 : 0);
    cout << "Outer at 9 AM: fare = " << fare << " paise\n";

    int concession = 50;           // senior
    fare -= fare * concession / 100;   // compound assignment: right side done first
    cout << "After 50% senior concession: " << fare << " paise\n";

    // wrong precedence example
    long long wrong = base + peak ? base * 20 / 100 : 0;   // + is done before ?:
    cout << "Without brackets 'base + peak ? ... : 0' = " << wrong << " (wrong!)\n\n";

    // x++ vs ++x
    int i = 5;
    int a = i++;   // a = 5, then i = 6
    int b = ++i;   // i = 7, then b = 7
    cout << "a=i++ -> " << a << ", b=++i -> " << b << ", i=" << i << "\n";
    // i = i++;    // mistake: modifies i twice; result was undefined before C++17
    cout << "-7/2 = " << -7 / 2 << ", -7%2 = " << -7 % 2 << " (C++ truncates toward zero)\n\n";

    // time measurement: 100 million checks each
    const int N = 100000000;
    volatile int sink = 0;
    auto t1 = chrono::high_resolution_clock::now();
    for (int n = 0; n < N; n++) sink = sink + isPeakExpr(n % 24);
    auto t2 = chrono::high_resolution_clock::now();
    for (int n = 0; n < N; n++) sink = sink + isPeakTable(n % 24);
    auto t3 = chrono::high_resolution_clock::now();

    double ms1 = chrono::duration<double, milli>(t2 - t1).count();
    double ms2 = chrono::duration<double, milli>(t3 - t2).count();
    cout << "100 million checks, && || expression: " << ms1 << " ms\n";
    cout << "100 million checks, lookup table    : " << ms2 << " ms\n";
    cout << "Extra space for table = " << sizeof(PEAK_TABLE) << " bytes\n";
    return 0;
}
