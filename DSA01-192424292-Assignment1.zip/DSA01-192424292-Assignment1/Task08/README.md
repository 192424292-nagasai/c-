# Task 8 - Read and Print Data Safely

## Files
| File | What it does |
|---|---|
| task8_gate_io.cpp | reads journeys with cin >>, checks cin.fail(), cin.clear() + cin.ignore(), prints a report with iomanip |
| task8_getline_version.cpp | alternative: getline + stoi inside try/catch |
| input.txt | 11 journey lines, 5 of them wrong on purpose |

Run:
```
./task8_gate_io < input.txt
./task8_getline_version < input.txt
```

## input.txt (zone hour minute type)
| Line | Data | Problem |
|---|---|---|
| 1 | 0 7 45 A | ok |
| 2 | 2 8 30 A | ok (peak) |
| 3 | 1 abc 15 S | letters for hour |
| 4 | 1 12 15 S | ok (student) |
| 5 | x 9 0 A | letter for zone |
| 6 | 2 18 0 C | ok (senior, peak) |
| 7 | 3 11 0 A | unknown zone 3 |
| 8 | 1 20 0 A | ok (8 PM = off-peak) |
| 9 | 0 9 61 A | minute 61 |
| 10 | 2 17 30 Z | unknown passenger type |
| 11 | 2 9 15 A | ok (peak) |

## How recovery works
```cpp
cin >> value;
if (cin.fail()) {
    cin.clear();                                          // remove the error flag
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  // throw away the rest of the bad line
}
```
Without `clear()` every later `cin >>` would fail too, and without `ignore()` the same letters would be read again forever.

## Result
6 journeys accepted, 5 skipped with a message, total fare Rs 137.00, closing balance Rs 63.00. Report is printed with `setw` (column width), `setfill('0')` (times like 07:45), `fixed` and `setprecision(2)` (opening balance Rs 200.00).

The getline version found the same 6 valid lines and the same total (13700 paise).

## Alternative concept and complexity
| | cin >> with fail()/clear() | getline + stoi + try/catch |
|---|---|---|
| Time for a line of length L | O(L) | O(L) |
| Extra buffer | none (reads from the stream) | one string of L characters (+ stringstream) |
| Recovery | must clear() and ignore() by hand, easy to forget | whole line is read first, so a bad line can never block the next one; error message comes from the exception |
| Detecting "12abc" | cin reads 12 and leaves "abc" | checked with the `used` position from stoi |
