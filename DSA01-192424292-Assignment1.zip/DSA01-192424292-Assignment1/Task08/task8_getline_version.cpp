// Task 8 - Alternative: read whole line with getline, convert with stoi in try/catch
// Same input.txt as task8_gate_io.cpp
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
using namespace std;

constexpr long long BASE[] = {1000, 2000, 3000};

int main()
{
    string line;
    int lineNo = 0, ok = 0;
    long long total = 0;
    while (getline(cin, line)) {
        lineNo++;
        if (line.empty()) continue;
        stringstream ss(line);
        string zs, hs, ms, ts;
        ss >> zs >> hs >> ms >> ts;
        try {
            size_t used = 0;
            int zone = stoi(zs, &used);
            if (used != zs.size()) throw invalid_argument("zone");
            int h = stoi(hs, &used);
            if (used != hs.size()) throw invalid_argument("hour");
            int m = stoi(ms, &used);
            if (used != ms.size()) throw invalid_argument("minute");
            if (zone < 0 || zone > 2) throw out_of_range("zone " + zs);
            if (h < 0 || h > 23 || m < 0 || m > 59) throw out_of_range("time " + hs + ":" + ms);
            if (ts != "A" && ts != "S" && ts != "C") throw invalid_argument("type " + ts);

            int t = h * 60 + m;
            long long f = BASE[zone];
            if ((t >= 480 && t < 600) || (t >= 1020 && t < 1200)) f += f * 20 / 100;
            if (ts == "S") f -= f * 15 / 100;
            if (ts == "C") f -= f * 50 / 100;
            total += f;
            ok++;
            cout << "Line " << lineNo << " OK   fare " << f << " paise\n";
        } catch (const invalid_argument& e) {
            cout << "Line " << lineNo << " BAD  \"" << line << "\" -> not a number / bad value (" << e.what() << ")\n";
        } catch (const out_of_range& e) {
            cout << "Line " << lineNo << " BAD  \"" << line << "\" -> out of range (" << e.what() << ")\n";
        }
    }
    cout << "Valid lines: " << ok << ", total fare (no balance check) " << total << " paise\n";
    return 0;
}
