// Task 8 - Safe input with cin.fail()/cin.clear() and neat money output
// Input (input.txt), per journey:  zone(0-2)  hour  minute  type(A/S/C)
// Name: J.Nagasai   Reg No: 192424292

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
using namespace std;

constexpr long long BASE[] = {1000, 2000, 3000};
const string ZONE_NAME[] = {"Inner", "Middle", "Outer"};

bool isPeak(int h, int m)
{
    int t = h * 60 + m;
    return (t >= 480 && t < 600) || (t >= 1020 && t < 1200);
}

// reads one int, if letters are typed it clears the error and skips the line
bool readInt(const string& what, int low, int high, int& value)
{
    cin >> value;
    if (cin.fail()) {
        cin.clear();                                          // clear error state
        cin.ignore(numeric_limits<streamsize>::max(), '\n');  // discard bad line
        cout << "  ! invalid input for " << what << " (not a number) - journey skipped\n";
        return false;
    }
    if (value < low || value > high) {
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "  ! " << what << " " << value << " out of range " << low << "-" << high
             << " - journey skipped\n";
        return false;
    }
    return true;
}

string rs(long long p)      // money as text, e.g. 3600 -> "36.00"
{
    string s = to_string(p / 100) + ".";
    if (p % 100 < 10) s += "0";
    return s + to_string(p % 100);
}

int main()
{
    long long balance = 20000;    // Rs 200
    int no = 0;
    long long total = 0;

    cout << "Opening balance Rs " << fixed << setprecision(2) << balance / 100.0 << "\n";
    cout << "Reading journeys...\n";

    struct Row { int no; int zone; int h; int m; char type; long long fare; long long bal; };
    Row rows[50];
    int n = 0;

    while (cin >> ws && !cin.eof()) {
        no++;
        int zone, h, m;
        char type;
        if (!readInt("zone", 0, 2, zone)) continue;
        if (!readInt("hour", 0, 23, h)) continue;
        if (!readInt("minute", 0, 59, m)) continue;
        cin >> type;
        if (type != 'A' && type != 'S' && type != 'C') {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "  ! passenger type '" << type << "' unknown - journey skipped\n";
            continue;
        }
        long long f = BASE[zone];
        if (isPeak(h, m)) f += f * 20 / 100;
        if (type == 'S') f -= f * 15 / 100;
        if (type == 'C') f -= f * 50 / 100;
        if (balance - f < 5000) {
            cout << "  ! journey " << no << " denied - low balance\n";
            continue;
        }
        balance -= f;
        total += f;
        rows[n++] = {no, zone, h, m, type, f, balance};
    }

    cout << "\n=================== JOURNEY REPORT ===================\n";
    cout << left << setw(5) << "No" << setw(9) << "Zone" << setw(8) << "Time"
         << setw(6) << "Type" << setw(9) << "Peak" << right << setw(9) << "Fare"
         << setw(11) << "Balance" << "\n";
    cout << "------------------------------------------------------\n";
    for (int i = 0; i < n; i++) {
        cout << left << setw(5) << rows[i].no << setw(9) << ZONE_NAME[rows[i].zone]
             << right << setfill('0') << setw(2) << rows[i].h << ":" << setw(2) << rows[i].m
             << setfill(' ') << left << "   " << setw(6) << rows[i].type
             << setw(9) << (isPeak(rows[i].h, rows[i].m) ? "yes" : "no")
             << right << setw(9) << rs(rows[i].fare) << setw(11) << rs(rows[i].bal) << "\n";
    }
    cout << "------------------------------------------------------\n";
    cout << "Journeys accepted: " << n << "   Total fare Rs " << rs(total)
         << "   Closing balance Rs " << rs(balance) << "\n";
    return 0;
}
