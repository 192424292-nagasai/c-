# Task 10 - Compare Expectations with Execution

## Files
| File | What it does |
|---|---|
| task10_totals.cpp | day totals in double rupees, long long paise and int for 20,000 / 500,000 / 3,000,000 journeys + time per addition |
| warnings_demo.cpp | a "hurry" program to collect -Wall -Wextra warnings |
| output/warnings_demo_compile.txt | all warnings received |

Journeys are generated with a fixed pattern (zone = i % 3, peak if i % 4 == 0, senior if i % 7 == 0, else student if i % 5 == 0), so every run gives the same totals. No input file is needed.

## Measured totals
| Journeys | long long paise (exact) | double rupees | double - exact | int |
|---|---|---|---|---|
| 20,000 (1 station) | Rs 379,187.60 | 379187.600000 | 2.0e-09 | ok |
| 500,000 (1 line) | Rs 9,479,991.00 | 9479991.000000 | 2.2e-07 | ok |
| 3,000,000 (network) | Rs 56,880,002.40 | 56880002.400039 | 3.9e-05 | **overflow at journey 1,132,640** |

## Expected vs observed
- Expected: double would be slightly wrong. Observed: it was wrong in the tiny digits (up to 3.9e-05 rupees) and the error grows with n, but after rounding to paise it still matched. With more journeys or many fares like 10.20 it can cross half a paisa (Task 3 showed 1.5e-03 for 3 million Rs 10.20 fares).
- Expected: int would overflow for the network. Observed: yes, INT_MAX = 2,147,483,647 paise (about Rs 2.1 crore) was crossed at journey 1,132,640. A wrapped int would show 1,393,032,944 paise - a wrong but believable number, which is dangerous.
- long long was exact for all three sizes.

## Compiler warnings (-Wall -Wextra) and meaning
| Warning | Meaning |
|---|---|
| comparison of integer expressions of different signedness [-Wsign-compare] | int i compared with vector.size() (unsigned) |
| suggest parentheses around '&&' within '\|\|' [-Wparentheses] | peak expression without brackets, hard to read |
| suggest parentheses around assignment used as truth value | `if (balance = 0)` - should be `==` |
| unused variable 'unusedTotal' | variable declared but never used |
| unused parameter 'argc' / 'argv' | main parameters not used |
| control reaches end of non-void function [-Wreturn-type] | fareFor() has no return for an unknown zone - undefined value |
| (Task 4) different signedness in `s < u` | -1 becomes a big unsigned number |
| (Task 12) enumeration value 'Airport' not handled in switch [-Wswitch] | new enum value missing in switch |

## Reasons for the differences
1. double stores binary fractions; 1.2, 0.85, 10.2 cannot be stored exactly, so every addition rounds a little.
2. int is only 32 bits; the network total needs about 33 bits.
3. long long (64 bits) + whole paise avoids both problems.

## Alternative concept and complexity: total in int / long long / double at 3,000,000 journeys
| Type | Size | What happens | Measured time per addition |
|---|---|---|---|
| int | 4 bytes | overflow (wrong total) after ~1.13 million journeys | about 2.5 ns |
| long long | 8 bytes | exact, max 9.2 x 10^18 paise | about 2.4 ns |
| double | 8 bytes | no overflow, but loss of precision grows with n (beyond 2^53 paise it cannot even count by 1) | about 3.0 ns |

All are O(1) per addition and O(1) space; only long long is both exact and big enough.
