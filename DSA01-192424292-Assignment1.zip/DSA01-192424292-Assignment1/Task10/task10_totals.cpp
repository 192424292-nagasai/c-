// Task 10 - Expectation vs execution: day totals in double, int and long long
// for 20,000 / 500,000 / 3,000,000 journeys
// Journeys are made with a fixed pattern so the result is repeatable:
//   zone = i % 3, peak if i % 4 == 0, student if i % 5 == 0, senior if i % 7 == 0
// Name: J.Nagasai   Reg No: 192424292

#include <chrono>
#include <climits>
#include <cmath>
#include <iomanip>
#include <iostream>
using namespace std;

const double BASE_RS[] = {10.0, 20.0, 30.0};
const long long BASE_PAISE[] = {1000, 2000, 3000};

double fareRupees(long long i)          // the "hurry" version with double
{
    double f = BASE_RS[i % 3];
    if (i % 4 == 0) f = f * 1.2;
    if (i % 7 == 0) f = f * 0.5;
    else if (i % 5 == 0) f = f * 0.85;
    return f;
}

long long farePaise(long long i)        // exact version with integer paise
{
    long long f = BASE_PAISE[i % 3];
    if (i % 4 == 0) f += f * 20 / 100;
    if (i % 7 == 0) f -= f * 50 / 100;
    else if (i % 5 == 0) f -= f * 15 / 100;
    return f;
}

int main()
{
    long long sizes[] = {20000, 500000, 3000000};
    const char* names[] = {"1 station", "1 line", "whole network"};

    for (int s = 0; s < 3; s++) {
        long long n = sizes[s];
        double dTotal = 0.0;
        long long llTotal = 0;
        int intTotal = 0;
        long long overflowAt = -1;

        for (long long i = 0; i < n; i++) {
            dTotal += fareRupees(i);
            long long f = farePaise(i);
            llTotal += f;
            // int total: check before adding so we do not cause undefined behaviour
            if (overflowAt == -1 && intTotal > INT_MAX - f) overflowAt = i + 1;
            if (overflowAt == -1) intTotal += static_cast<int>(f);
        }
        // what a wrapped 32-bit int would show
        long long wrapped = llTotal % 4294967296LL;
        if (wrapped > INT_MAX) wrapped -= 4294967296LL;

        cout << "=== " << names[s] << ": " << n << " journeys ===\n";
        cout << fixed << setprecision(6);
        cout << "double total      : Rs " << dTotal << "\n";
        cout << "long long total   : " << llTotal << " paise = Rs " << llTotal / 100 << "."
             << setw(2) << setfill('0') << llTotal % 100 << setfill(' ') << "\n";
        cout << "double - exact    : Rs " << scientific << setprecision(3)
             << dTotal - llTotal / 100.0 << fixed << "\n";
        cout << "double in paise   : " << setprecision(0) << llround(dTotal * 100)
             << (llround(dTotal * 100) == llTotal ? "  (matches after rounding)" : "  (DIFFERENT)") << "\n";
        if (overflowAt == -1)
            cout << "int total         : " << intTotal << " paise (no overflow)\n";
        else
            cout << "int total         : OVERFLOW at journey " << overflowAt
                 << ", a wrapped int would show " << wrapped << " paise\n";
        cout << "\n";
    }

    // time per addition for int, long long, double
    const int N = 200000000;
    volatile int vi = 0;
    volatile long long vl = 0;
    volatile double vd = 0;
    auto t0 = chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) vi = vi + 1;
    auto t1 = chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) vl = vl + 1;
    auto t2 = chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) vd = vd + 1.0;
    auto t3 = chrono::high_resolution_clock::now();
    cout << setprecision(3);
    cout << "Time per addition (200 million adds):\n";
    cout << "  int       " << chrono::duration<double, nano>(t1 - t0).count() / N << " ns, size " << sizeof(int) << " bytes\n";
    cout << "  long long " << chrono::duration<double, nano>(t2 - t1).count() / N << " ns, size " << sizeof(long long) << " bytes\n";
    cout << "  double    " << chrono::duration<double, nano>(t3 - t2).count() / N << " ns, size " << sizeof(double) << " bytes\n";
    return 0;
}
