// Task 10 - small program written the "hurry" way, to collect -Wall -Wextra warnings
// Compile: g++ -std=c++17 -Wall -Wextra warnings_demo.cpp -o warnings_demo
// Name: J.Nagasai   Reg No: 192424292

#include <iostream>
#include <vector>

int fareFor(int zone)
{
    switch (zone) {
        case 0: return 1000;
        case 1: return 2000;
        case 2: return 3000;
    }
    // missing return here
}

int main(int argc, char* argv[])
{
    std::vector<int> fares = {1000, 3600, 2000};
    int unusedTotal = 0;

    for (int i = 0; i < fares.size(); i++)      // signed vs unsigned compare
        std::cout << fares[i] << '\n';

    int hour = 10;
    if (hour >= 8 && hour <= 10 || hour >= 17 && hour < 20)   // && inside || without ()
        std::cout << "peak\n";

    int balance = 5000;
    if (balance = 0)                              // = instead of ==
        std::cout << "empty\n";

    std::cout << fareFor(1) << '\n';
    return 0;
}
